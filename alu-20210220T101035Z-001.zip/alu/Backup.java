/*
package alu;


6,2
Substitution
Zero blockers chosen
Too many blockers chosen for block error
red card
switch all directional toggles for when teams switch sides.
Max players reached counter
Team reception error. gotta say someone received it then correct it to be a team error.

Block- section that lights up selected hitters. keep the right stick three direction thing. have a counter that counts if three for triple two for double one for single. if position turned on - plus one. if turned off - minus one


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Scanner;*/

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Aug 8, 2018
 */

/*public class Backup
{
    package alu;

import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;*/

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */
/*
public class Volley extends Player implements KeyListener
{
    private int contactCounter;
    private int logCounter;
    
    private boolean firstButtonPressedToggle;
    private boolean continueToggle;
    private boolean overToggle;
    
    private boolean blockToggle;
    private boolean blockTypeChosen;
    private boolean blockerChosen;
    private boolean soloBlockOn;
    private boolean blockAssistOn;
    private boolean MHBlockOn;
    private boolean OHBlockOn;
    private boolean OPPBlockOn;
    private boolean OHBackBlockOn;
    private boolean LiberoBlockOn;
    private boolean SetterBlockOn;
            
    private boolean possession; //Team 2- False. Team 1- True
    
    private ArrayList<Player> playerLog;
    private ArrayList<String> actionLog;
    
    
    private Player team1Starters[];
    private Player team2Starters[];
    private Player team1[];
    private Player team2[];
    
          
    
    public Volley()
    {
        contactCounter = 0;
        logCounter = 0;
        
        firstButtonPressedToggle = false;
        continueToggle = false;
        overToggle = false;
        
        blockToggle = false;
        blockTypeChosen = false;
        blockerChosen = false;
        soloBlockOn = false;
        blockAssistOn = false;
        MHBlockOn = false;
        OHBlockOn = false;
        OPPBlockOn = false;
        OHBackBlockOn = false;
        LiberoBlockOn = false;
        SetterBlockOn = false;
        
        possession = true;
        
        playerLog = new ArrayList(0);
        actionLog = new ArrayList(0);
        
        
        
        team1Starters = new Player[8];
        team2Starters = new Player[8];
        team1 = new Player[30];
        team2 = new Player[30];
        
    }
    
    public void init()
    {
        this.addKeyListener(this);
    }
    
    public void createRoster()
    {
        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();
        Player p4 = new Player();
        Player p5 = new Player();
        Player p6 = new Player();
        Player p7 = new Player();
        Player p8 = new Player();
        Player p9 = new Player();
        Player p10 = new Player();
        Player p11 = new Player();
        Player p12 = new Player();
        Player p13 = new Player();
        Player p14 = new Player();
        Player p15 = new Player();
        Player p16 = new Player();
        Player p17 = new Player();
        Player p18 = new Player();
        Player p19 = new Player();
        Player p20 = new Player();
        Player p21 = new Player();
        Player p22 = new Player();
        Player p23 = new Player();
        Player p24 = new Player();
        Player p25 = new Player();
        Player p26 = new Player();
        Player p27 = new Player();
        Player p28 = new Player();
        Player p29 = new Player();
        Player p30 = new Player();
        Player p31 = new Player();
        Player p32 = new Player();
        Player p33 = new Player();
        Player p34 = new Player();
        Player p35 = new Player();
        Player p36 = new Player();
        Player p37 = new Player();
        Player p38 = new Player();
        Player p39 = new Player();
        Player p40 = new Player();
        Player p41 = new Player();
        Player p42 = new Player();
        Player p43 = new Player();
        Player p44 = new Player();
        Player p45 = new Player();
        Player p46 = new Player();
        Player p47 = new Player();
        Player p48 = new Player();
        Player p49 = new Player();
        Player p50 = new Player();
        Player p51 = new Player();
        Player p52 = new Player();
        Player p53 = new Player();
        Player p54 = new Player();
        Player p55 = new Player();
        Player p56 = new Player();
        Player p57 = new Player();
        Player p58 = new Player();
        Player p59 = new Player();
        Player p60 = new Player();
        
        team1[0] = p1;
        team1[1] = p2;
        team1[2] = p3;
        team1[3] = p4;
        team1[4] = p5;
        team1[5] = p6;
        team1[6] = p7;
        team1[7] = p8;
        team1[8] = p9;
        team1[9] = p10;
        team1[10] = p11;
        team1[11] = p12;
        team1[12] = p13;
        team1[13] = p14;
        team1[14] = p15;
        team1[15] = p16;
        team1[16] = p17;
        team1[17] = p18;
        team1[18] = p19;
        team1[19] = p20;
        team1[20] = p21;
        team1[21] = p22;
        team1[22] = p23;
        team1[23] = p24;
        team1[24] = p25;
        team1[25] = p26;
        team1[26] = p27;
        team1[27] = p28;
        team1[28] = p29;
        team1[29] = p30;
        
        team2[0] = p1;
        team2[1] = p2;
        team2[2] = p3;
        team2[3] = p4;
        team2[4] = p5;
        team2[5] = p6;
        team2[6] = p7;
        team2[7] = p8;
        team2[8] = p9;
        team2[9] = p10;
        team2[10] = p11;
        team2[11] = p12;
        team2[12] = p13;
        team2[13] = p14;
        team2[14] = p15;
        team2[15] = p16;
        team2[16] = p17;
        team2[17] = p18;
        team2[18] = p19;
        team2[19] = p20;
        team2[20] = p21;
        team2[21] = p22;
        team2[22] = p23;
        team2[23] = p24;
        team2[24] = p25;
        team2[25] = p26;
        team2[26] = p27;
        team2[27] = p28;
        team2[28] = p29;
        team2[29] = p30;
    }
    
    public int chooseTeam()
    {
        //Which Team
        Scanner enter = new Scanner(System.in);
        
        int num=0;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter which team (1 or 2)"); 
            try
            {
                num = enter.nextInt();
                pass = true;
                
                if(num != 1 || num != 2)
                {
                    pass = false;
                    System.out.println("Number is not 1 or 2. Reboot");
                }
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//while
        return num;
    }
    
    public void createPlayer()
    {  
        if(chooseTeam()==1)
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    team1[i].setPlayerPosition();
                }
            }
        }
        else
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    team1[i].setPlayerPosition();
                }
            }
        }
    }//create Player

    
    public void establishSetter()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the setter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[1] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[1] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishSetter
    
    public void establishOH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 2 (Following Setter)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[2] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[2] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH2
    
    public void establishMH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 2 (Follows OH2)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[3] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[3] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH2
    
    public void establishOP()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Opposite Hitter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[4] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[4] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOP
    
    public void establishOH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 1(Follows Opposite)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[5] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[5] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH1
    
    public void establishMH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 1"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[6] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[6] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH1
    
    public void establishLibero()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Starting Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[0] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[0] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLibero
    
    public void establishLiberoR()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Reserved Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[7] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[7] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLiberoR
    
    public int getContactCounter()
    {
        return contactCounter;
    }
    
    
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`    
    @Override
    public void keyPressed(KeyEvent e)
    {
        //1-Middle Hitter
        if(e.getKeyCode() == KeyEvent.VK_Q)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    MHBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[3]);
                            actionLog.set(logCounter, "x");
                        }
                        //MH1
                        else
                        {
                            playerLog.set(logCounter, team1Starters[6]);
                            actionLog.set(logCounter, "x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[3]);
                            actionLog.set(logCounter, "x");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[6]);
                            actionLog.set(logCounter, "x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[3]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team1Starters[6]);
                            actionLog.set(logCounter, "dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[3]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[6]);
                            actionLog.set(logCounter, "dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[3]);
                        actionLog.set(logCounter, "set");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[6]);
                        actionLog.set(logCounter, "set");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[3]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[6]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[3]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[6]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[3]);
                        actionLog.set(logCounter, "attack");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[6]);
                        actionLog.set(logCounter, "attack");
                    }
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            }       
        }//End of middle hitter
    
        //2-Outside Hitter
        else if(e.getKeyCode() == KeyEvent.VK_W)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? OH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[2]);
                            actionLog.set(logCounter, "x");
                        }
                        //MH1
                        else
                        {
                            playerLog.set(logCounter, team1Starters[5]);
                            actionLog.set(logCounter, "x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[2]);
                            actionLog.set(logCounter, "x");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[5]);
                            actionLog.set(logCounter, "x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[2]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team1Starters[5]);
                            actionLog.set(logCounter, "dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[2]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[5]);
                            actionLog.set(logCounter, "dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[3]);
                        actionLog.set(logCounter, "set");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[6]);
                        actionLog.set(logCounter, "set");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[2]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[5]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[2]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[5]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[2]);
                        actionLog.set(logCounter, "attack");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[5]);
                        actionLog.set(logCounter, "attack");
                    }
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter
        //3-Opposite Hitter
        else if(e.getKeyCode() == KeyEvent.VK_E)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OPPBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[4]);
                        actionLog.set(logCounter, "x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.set(logCounter, team2Starters[4]);
                        actionLog.set(logCounter, "x");
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[4]);
                        actionLog.set(logCounter, "dig");    
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[4]);
                        actionLog.set(logCounter, "dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[4]);
                    actionLog.set(logCounter, "set");
                }                
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[4]);
                    actionLog.set(logCounter, "zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[4]);
                    actionLog.set(logCounter, "zeroAssist");
                }
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[4]);
                    actionLog.set(logCounter, "attack");
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Opposite
        //4-Outside Hitter (Back Row)
        else if(e.getKeyCode() == KeyEvent.VK_R)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBackBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[5]);
                            actionLog.set(logCounter, "x");
                        }
                        //MH1
                        else
                        {
                            playerLog.set(logCounter, team1Starters[2]);
                            actionLog.set(logCounter, "x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[5]);
                            actionLog.set(logCounter, "x");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[2]);
                            actionLog.set(logCounter, "x");
                        }
                    }  
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team1Starters[5]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team1Starters[2]);
                            actionLog.set(logCounter, "dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.set(logCounter, team2Starters[5]);
                            actionLog.set(logCounter, "dig");
                        }
                        else
                        {
                            playerLog.set(logCounter, team2Starters[2]);
                            actionLog.set(logCounter, "dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[5]);
                        actionLog.set(logCounter, "set");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[2]);
                        actionLog.set(logCounter, "set");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[5]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[2]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team1Starters[3]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.set(logCounter, team1Starters[6]);
                        actionLog.set(logCounter, "zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.set(logCounter, team2Starters[5]);
                        actionLog.set(logCounter, "attack");
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[2]);
                        actionLog.set(logCounter, "attack");
                    }
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter (Back Row)
        //5-Libero
        else if(e.getKeyCode() == KeyEvent.VK_T)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    LiberoBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            if(libero is in? no? do middle hitter button)
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[0]);
                        actionLog.set(logCounter, "x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.set(logCounter, team2Starters[0]);
                        actionLog.set(logCounter, "x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[0]);
                        actionLog.set(logCounter, "dig");    
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[0]);
                        actionLog.set(logCounter, "dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[0]);
                    actionLog.set(logCounter, "set");
                }                
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[0]);
                    actionLog.set(logCounter, "zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[0]);
                    actionLog.set(logCounter, "zeroAssist");
                }
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[0]);
                    actionLog.set(logCounter, "attack");
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }// End of Libero
        //6-Setter
        else if(e.getKeyCode() == KeyEvent.VK_Y)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    SetterBlockOn = true;
                }
                return;
            }
            //So a person does not hit attack button before a player is pressed.
            firstButtonPressedToggle = true;
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[1]);
                        actionLog.set(logCounter, "x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.set(logCounter, team2Starters[1]);
                        actionLog.set(logCounter, "x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.set(logCounter, team1Starters[1]);
                        actionLog.set(logCounter, "dig");    
                    }
                    else
                    {
                        playerLog.set(logCounter, team2Starters[1]);
                        actionLog.set(logCounter, "dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[1]);
                    actionLog.set(logCounter, "set");
                }                
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[1]);
                    actionLog.set(logCounter, "zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.set(logCounter, team1Starters[1]);
                    actionLog.set(logCounter, "zeroAssist");
                }
                //Team 2
                else
                {
                    playerLog.set(logCounter, team2Starters[1]);
                    actionLog.set(logCounter, "attack");
                }
            }
            logCounter++;
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Setter
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
        
        //7-Attack
        else if(e.getKeyCode() == KeyEvent.VK_U)
        {
            if(firstButtonPressedToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(logCounter-1, "attack");
                logCounter++;
                contactCounter = 0;
                possession = !possession;
            }
        }
        //8-Over
        else if(e.getKeyCode() == KeyEvent.VK_I)
        {
            if(firstButtonPressedToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                overToggle = true;
                contactCounter = 0;
                possession = !possession;
            }
        }
        //9-Continue
        else if(e.getKeyCode() == KeyEvent.VK_O)
        {
            firstButtonPressedToggle=false;
            continueToggle = true;
            contactCounter = 0;
        }
        //10-Kill
        else if(e.getKeyCode() == KeyEvent.VK_P)
        {
            if(firstButtonPressedToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(logCounter-1, "kill");
                if(actionLog.get(logCounter-2).equals("dig"))
                {
                    actionLog.set(logCounter-2, "dig&assist");
                }
                else
                {
                    actionLog.set(logCounter-2, "assist");
                }
                logCounter++;
                contactCounter = 0;
                possession=!possession;
            }
        }
        //11-Block
        else if(e.getKeyCode() == KeyEvent.VK_A)
        {
            firstButtonPressedToggle=false;
            boolean trapWhile = true;
            blockToggle=true;
            while(trapWhile)
            {
                if(soloBlockOn)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team1Starters[3]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.set(logCounter, team1Starters[6]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team2Starters[3]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            else
                            {
                                playerLog.set(logCounter, team2Starters[6]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team1Starters[2]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.set(logCounter, team1Starters[5]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team2Starters[2]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            else
                            {
                                playerLog.set(logCounter, team2Starters[5]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.set(logCounter, team1Starters[4]);
                            actionLog.set(logCounter, "soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.set(logCounter, team2Starters[4]);
                            actionLog.set(logCounter, "soloBlock");
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team1Starters[5]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.set(logCounter, team1Starters[2]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.set(logCounter, team2Starters[5]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            else
                            {
                                playerLog.set(logCounter, team2Starters[2]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.set(logCounter, team1Starters[0]);
                            actionLog.set(logCounter, "soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.set(logCounter, team2Starters[0]);
                            actionLog.set(logCounter, "soloBlock");
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.set(logCounter, team1Starters[1]);
                            actionLog.set(logCounter, "soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.set(logCounter, team2Starters[1]);
                            actionLog.set(logCounter, "soloBlock");
                        }
                        SetterBlockOn = false;
                    }
                    soloBlockOn = false;
                    blockTypeChosen = false;
                    blockerChosen = false;
                    return;
                }
                if(blockAssistOn)
                {
                    Player BlockplayerLog[] = new Player[2];
                    String BlockactionLog[] = new String[2];
                    
                    int two = 0;
                    while(two<=2)
                    {
                        if(MHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team1Starters[3]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.set(logCounter, team1Starters[6]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team2Starters[3]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                else
                                {
                                    playerLog.set(logCounter, team2Starters[6]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            MHBlockOn = false;
                            blockerChosen = false;
                        }
                        else if(OHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? OH2
                                if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team1Starters[2]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.set(logCounter, team1Starters[5]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team2Starters[2]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                else
                                {
                                    playerLog.set(logCounter, team2Starters[5]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            OHBlockOn = false;
                            blockerChosen = false;
                        }
                        else if(OPPBlockOn)
                        {
                            if(possession)
                            {
                                playerLog.set(logCounter, team1Starters[4]);
                                actionLog.set(logCounter, "soloBlock");                       
                            }
                            //Team 2
                            else
                            {
                                playerLog.set(logCounter, team2Starters[4]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            OPPBlockOn = false;
                            blockerChosen = false;
                        }
                        else if(OHBackBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team1Starters[5]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.set(logCounter, team1Starters[2]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                                {
                                    playerLog.set(logCounter, team2Starters[5]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                                else
                                {
                                    playerLog.set(logCounter, team2Starters[2]);
                                    actionLog.set(logCounter, "soloBlock");
                                }
                            }
                            OHBackBlockOn = false;
                            blockerChosen = false;
                        }
                        else if(LiberoBlockOn)
                        {
                            if(possession)
                            {
                                playerLog.set(logCounter, team1Starters[0]);
                                actionLog.set(logCounter, "soloBlock");                       
                            }
                            //Team 2
                            else
                            {
                                playerLog.set(logCounter, team2Starters[0]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            LiberoBlockOn = false;
                            blockerChosen = false;
                        }
                        else if(SetterBlockOn)
                        {
                            if(possession)
                            {
                                playerLog.set(logCounter, team1Starters[1]);
                                actionLog.set(logCounter, "soloBlock");                       
                            }
                            //Team 2
                            else
                            {
                                playerLog.set(logCounter, team2Starters[1]);
                                actionLog.set(logCounter, "soloBlock");
                            }
                            SetterBlockOn = false;
                            blockerChosen = false;
                        }
                        blockAssistOn = false;
                        blockTypeChosen = false;
                        return;
                    }//while two    
                }//if blockAssist
            }//whileTrap
        }
        //12-Error
        else if(e.getKeyCode() == KeyEvent.VK_S)
        {
            firstButtonPressedToggle=false;
        }
        //13-Substitution
        else if(e.getKeyCode() == KeyEvent.VK_D)
        {
            
        }
        //14-Back
        else if(e.getKeyCode() == KeyEvent.VK_F)
        {
            
        }
        //15-Skip
        else if(e.getKeyCode() == KeyEvent.VK_G)
        {
            
        }
        //16-Enter
        else if(e.getKeyCode() == KeyEvent.VK_H)
        {
            
        }
        //16-SoloBlock
        else if(e.getKeyCode() == KeyEvent.VK_J)
        {
            if(blockToggle && !blockTypeChosen)
            {
                soloBlockOn=true;
            }
        }
        //16-BlockAssist
        else if(e.getKeyCode() == KeyEvent.VK_K)
        {
            if(blockToggle && !blockTypeChosen)
            {
                blockAssistOn=true;
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}   

}   











package alu;

import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;*/

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */

/*
public class Volley extends Player implements KeyListener
{
    private DoubleLinkedListSideOutTracker serveTrack;
    private int contactCounter;
    
    private boolean firstButtonPressedToggle;
    private boolean continueToggle;
    private boolean overToggle;
    
    private boolean errorToggle;
    
    private boolean blockToggle;
    private boolean blockTypeChosen;
    private boolean blockerChosen;
    private boolean soloBlockOn;
    private boolean blockAssistOn;
    private boolean MHBlockOn;
    private boolean OHBlockOn;
    private boolean OPPBlockOn;
    private boolean OHBackBlockOn;
    private boolean LiberoBlockOn;
    private boolean SetterBlockOn;
    
    private boolean liberoIn;
            
    private boolean possession; //Team 2- False. Team 1- True
    
    private ArrayList<Player> playerLog;
    private ArrayList<String> actionLog;
    
    
    private Player team1Starters[];
    private Player team2Starters[];
    private Player team1[];
    private Player team2[];
    private Player dummy;
    
          
    
    public Volley()
    {
        serveTrack = new DoubleLinkedListSideOutTracker();
        contactCounter = 0;
        
        firstButtonPressedToggle = false;
        continueToggle = false;
        overToggle = false;
        
        errorToggle = false;
        
        blockToggle = false;
        blockTypeChosen = false;
        blockerChosen = false;
        soloBlockOn = false;
        blockAssistOn = false;
        MHBlockOn = false;
        OHBlockOn = false;
        OPPBlockOn = false;
        OHBackBlockOn = false;
        LiberoBlockOn = false;
        SetterBlockOn = false;
        
        liberoIn = true;
        
        possession = true;
        
        playerLog = new ArrayList(0);
        actionLog = new ArrayList(0);
        
        
        
        team1Starters = new Player[8];
        team2Starters = new Player[8];
        team1 = new Player[30];
        team2 = new Player[30];
        dummy = new Player();
        
    }
    
    public void init()
    {
        this.addKeyListener(this);
    }
    
    public void createRoster()
    {
        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();
        Player p4 = new Player();
        Player p5 = new Player();
        Player p6 = new Player();
        Player p7 = new Player();
        Player p8 = new Player();
        Player p9 = new Player();
        Player p10 = new Player();
        Player p11 = new Player();
        Player p12 = new Player();
        Player p13 = new Player();
        Player p14 = new Player();
        Player p15 = new Player();
        Player p16 = new Player();
        Player p17 = new Player();
        Player p18 = new Player();
        Player p19 = new Player();
        Player p20 = new Player();
        Player p21 = new Player();
        Player p22 = new Player();
        Player p23 = new Player();
        Player p24 = new Player();
        Player p25 = new Player();
        Player p26 = new Player();
        Player p27 = new Player();
        Player p28 = new Player();
        Player p29 = new Player();
        Player p30 = new Player();
        Player p31 = new Player();
        Player p32 = new Player();
        Player p33 = new Player();
        Player p34 = new Player();
        Player p35 = new Player();
        Player p36 = new Player();
        Player p37 = new Player();
        Player p38 = new Player();
        Player p39 = new Player();
        Player p40 = new Player();
        Player p41 = new Player();
        Player p42 = new Player();
        Player p43 = new Player();
        Player p44 = new Player();
        Player p45 = new Player();
        Player p46 = new Player();
        Player p47 = new Player();
        Player p48 = new Player();
        Player p49 = new Player();
        Player p50 = new Player();
        Player p51 = new Player();
        Player p52 = new Player();
        Player p53 = new Player();
        Player p54 = new Player();
        Player p55 = new Player();
        Player p56 = new Player();
        Player p57 = new Player();
        Player p58 = new Player();
        Player p59 = new Player();
        Player p60 = new Player();
        
        team1[0] = p1;
        team1[1] = p2;
        team1[2] = p3;
        team1[3] = p4;
        team1[4] = p5;
        team1[5] = p6;
        team1[6] = p7;
        team1[7] = p8;
        team1[8] = p9;
        team1[9] = p10;
        team1[10] = p11;
        team1[11] = p12;
        team1[12] = p13;
        team1[13] = p14;
        team1[14] = p15;
        team1[15] = p16;
        team1[16] = p17;
        team1[17] = p18;
        team1[18] = p19;
        team1[19] = p20;
        team1[20] = p21;
        team1[21] = p22;
        team1[22] = p23;
        team1[23] = p24;
        team1[24] = p25;
        team1[25] = p26;
        team1[26] = p27;
        team1[27] = p28;
        team1[28] = p29;
        team1[29] = p30;
        
        team2[0] = p1;
        team2[1] = p2;
        team2[2] = p3;
        team2[3] = p4;
        team2[4] = p5;
        team2[5] = p6;
        team2[6] = p7;
        team2[7] = p8;
        team2[8] = p9;
        team2[9] = p10;
        team2[10] = p11;
        team2[11] = p12;
        team2[12] = p13;
        team2[13] = p14;
        team2[14] = p15;
        team2[15] = p16;
        team2[16] = p17;
        team2[17] = p18;
        team2[18] = p19;
        team2[19] = p20;
        team2[20] = p21;
        team2[21] = p22;
        team2[22] = p23;
        team2[23] = p24;
        team2[24] = p25;
        team2[25] = p26;
        team2[26] = p27;
        team2[27] = p28;
        team2[28] = p29;
        team2[29] = p30;
    }
    
    public int chooseTeam()
    {
        //Which Team
        Scanner enter = new Scanner(System.in);
        
        int num=0;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter which team (1 or 2)"); 
            try
            {
                num = enter.nextInt();
                pass = true;
                
                if(num != 1 || num != 2)
                {
                    pass = false;
                    System.out.println("Number is not 1 or 2. Reboot");
                }
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//while
        return num;
    }
    
    public void createPlayer()
    {  
        if(chooseTeam()==1)
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    team1[i].setPlayerPosition();
                }
            }
        }
        else
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    team1[i].setPlayerPosition();
                }
            }
        }
    }//create Player

    
    public void establishSetter()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the setter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[1] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[1] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishSetter
    
    public void establishOH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 2 (Following Setter)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[2] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[2] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH2
    
    public void establishMH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 2 (Follows OH2)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[3] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[3] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH2
    
    public void establishOP()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Opposite Hitter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[4] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[4] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOP
    
    public void establishOH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 1(Follows Opposite)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[5] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[5] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH1
    
    public void establishMH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 1"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[6] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[6] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH1
    
    public void establishLibero()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Starting Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[0] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[0] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLibero
    
    public void establishLiberoR()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Reserved Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[7] = team1[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[7] = team2[i];
                        }
                        else
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLiberoR
    
    public void rotate()
    {
        if(serveTrack.last.prev.prev == serveTrack.last.prev)
            {
                return;
            }
        else if(possession)
        {
            team1Starters[0].addPosition();
            team1Starters[1].addPosition();
            team1Starters[2].addPosition();
            team1Starters[3].addPosition();
            team1Starters[4].addPosition();
            team1Starters[5].addPosition();
            team1Starters[6].addPosition();
            team1Starters[7].addPosition();
            
            
        }
        else
        {
            team2Starters[0].addPosition();
            team2Starters[1].addPosition();
            team2Starters[2].addPosition();
            team2Starters[3].addPosition();
            team2Starters[4].addPosition();
            team2Starters[5].addPosition();
            team2Starters[6].addPosition();
        }
    }
    
    public int getContactCounter()
    {
        return contactCounter;
    }
    
    
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`    
    @Override
    public void keyPressed(KeyEvent e)
    {
        //1-Middle Hitter
        if(e.getKeyCode() == KeyEvent.VK_Q)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    MHBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                contactCounter++;
                firstButtonPressedToggle = true;
            }
            //So a person does not hit attack button before a player is pressed.
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            }       
        }//End of middle hitter
    
        //2-Outside Hitter
        else if(e.getKeyCode() == KeyEvent.VK_W)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                contactCounter++;
                firstButtonPressedToggle = true;
            }//iffirsttoggle
            
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? OH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter
        //3-Opposite Hitter
        else if(e.getKeyCode() == KeyEvent.VK_E)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OPPBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                contactCounter++;
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("x");
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("attack");
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Opposite
        //4-Outside Hitter (Back Row)
        else if(e.getKeyCode() == KeyEvent.VK_R)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBackBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                contactCounter++;
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                    }  
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter (Back Row)
        //5-Libero
        else if(e.getKeyCode() == KeyEvent.VK_T)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    LiberoBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    if(liberoIn)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoIn)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                contactCounter++;
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        if(liberoIn)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("x");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(liberoIn)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("x");
                            }
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if(liberoIn)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("dig");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(liberoIn)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("dig");
                            }
                        }
                    }
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(liberoIn)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoIn)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(liberoIn)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("attack");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoIn)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("attack");
                        }
                    }
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }// End of Libero
        //6-Setter
        else if(e.getKeyCode() == KeyEvent.VK_Y)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    SetterBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                contactCounter++;
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("attack");
                }
            }
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Setter
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
        
        //7-Attack
        else if(e.getKeyCode() == KeyEvent.VK_U)
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-2, "attack");
                contactCounter = 0;
                possession = !possession;
            }
        }
        //8-Over
        else if(e.getKeyCode() == KeyEvent.VK_I)
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                overToggle = true;
                contactCounter = 0;
                possession = !possession;
            }
        }
        //9-Continue
        else if(e.getKeyCode() == KeyEvent.VK_O)
        {
            if(!blockToggle)
            {
                firstButtonPressedToggle=false;
                continueToggle = true;
                contactCounter = 0;
            }
        }
        //10-Kill
        else if(e.getKeyCode() == KeyEvent.VK_P)
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-2, "kill");
                if(actionLog.get(actionLog.size()-3).equals("dig"))
                {
                    actionLog.set(actionLog.size()-3, "dig&assist");
                }
                else
                {
                    actionLog.set(actionLog.size()-3, "assist");
                }
                contactCounter = 0;
                possession=!possession;
            }
            rotate();
        }
        //11-Block
        else if(e.getKeyCode() == KeyEvent.VK_A)
        {
            if(!firstButtonPressedToggle)
            {
                return;
            }
            
            actionLog.add("InCaseOfBlockError");
            playerLog.add(dummy);
            
            
            firstButtonPressedToggle=false;
            boolean trapWhile = true;
            blockToggle=true;
            while(trapWhile)
            {
                if(soloBlockOn)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("soloBlock");
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {~
                        if(possession)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("soloBlock");
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("soloBlock");
                        }
                        SetterBlockOn = false;
                    }
                    soloBlockOn = false;
                    blockTypeChosen = false;
                    blockerChosen = false;
                    return;
                }
                if(blockAssistOn)
                {
                    int miniActionLogCounter = 0;
                    Player BlockPlayerLog[] = new Player[2];
                    String BlockActionLog[] = new String[2];
                    
                    while(miniActionLogCounter<=1)
                    {
                        if(MHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            MHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? OH2
                                if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OPPBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                       
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            OPPBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBackBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBackBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(LiberoBlockOn)
                        {~
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[0];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                    
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[0];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            LiberoBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(SetterBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                    
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            SetterBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        if(miniActionLogCounter == 2)
                        {
                            if(BlockPlayerLog[0]==BlockPlayerLog[1])
                            {
                                System.out.println("A block assist consist of two different players blocking to earn a point and end the rally."
                                        + "You entered the same player twice. Did you mean for a soloBlock? Entering yes will give a solo block to the player you entered twice."
                                        + "Entering no will reset you to Block Assist-Then enter two different players");
                                miniActionLogCounter = 0;
                                BlockPlayerLog = new Player[2];
                                BlockActionLog = new String[2];
                            }
                            else
                            {
                                playerLog.add(BlockPlayerLog[0]);
                                actionLog.add(BlockActionLog[0]);
                                
                                playerLog.add(BlockPlayerLog[1]);
                                actionLog.add(BlockActionLog[1]);
                            }
                        }
                    }//while two
                    blockAssistOn = false;
                    blockTypeChosen = false;
                    return;
                }//if blockAssist
            }//whileTrap
            rotate();
            blockToggle=false;
        }
        //12-Error
        else if(e.getKeyCode() == KeyEvent.VK_S)
        {
            //Service Error
            if(!firstButtonPressedToggle && !blockToggle)
            {
                errorToggle = true;
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                
                            }
                            if(i==6 && liberoIn)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                rotate();
            }
            //Reception Error, Ball Handling Error, Attack Error, and blockError
            else //if(firstButtonPressedToggle && !blockToggle)
            {
                if(actionLog.get(actionLog.size()-2).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-2,"receptionError");
                }
                else if(actionLog.get(actionLog.size()-2).equals("zeroAssist") || actionLog.get(actionLog.size()-2).equals("dig") || actionLog.get(actionLog.size()-2).equals("x"))
                {
                    actionLog.set(actionLog.size()-2,"ballHandlingError");
                }
                else if(actionLog.get(actionLog.size()-2).equals("attack"))
                {
                    actionLog.set(actionLog.size()-2,"attackError");
                }
                else
                {
                    
                    actionLog.set(actionLog.size()-2,"attackError");
                }
                rotate();
            }
            
        }
        //13-Substitution
        else if(e.getKeyCode() == KeyEvent.VK_D)
        {
            
        }
        //14-Back
        else if(e.getKeyCode() == KeyEvent.VK_F)
        {
            
        }
        //15-Skip
        else if(e.getKeyCode() == KeyEvent.VK_G)
        {
            
        }
        //16-Enter
        else if(e.getKeyCode() == KeyEvent.VK_H)
        {
            
        }
        //16-SoloBlock
        else if(e.getKeyCode() == KeyEvent.VK_J)
        {
            if(blockToggle && !blockTypeChosen)
            {
                soloBlockOn=true;
            }
        }
        //16-BlockAssist
        else if(e.getKeyCode() == KeyEvent.VK_K)
        {
            if(blockToggle && !blockTypeChosen)
            {
                blockAssistOn=true;
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}   
if(possession)
                {
                    if(liberoIn)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoIn)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
*/

/*
package alu;

import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;*/

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */
/*
public class Volley extends Player implements KeyListener
{
    private DoubleLinkedListSideOutTracker serveTrack;
    private int contactCounter;
    
    private boolean firstButtonPressedToggle;
    private boolean continueToggle;
    private boolean overToggle;
    
    private boolean errorToggle;
    
    private boolean blockToggle;
    private boolean blockTypeChosen;
    private boolean blockerChosen;
    private boolean soloBlockOn;
    private boolean blockAssistOnDouble;
    private boolean blockAssistOnTriple;
    private boolean MHBlockOn;
    private boolean OHBlockOn;
    private boolean OPPBlockOn;
    private boolean OHBackBlockOn;
    private boolean LiberoBlockOn;
    private boolean SetterBlockOn;
    
    private boolean substitutionToggleOn;
    private boolean subEnterToggle;
    private int substitutionNumber;
    private boolean teamSubSelect;
    private boolean homeTeamSubSelected;
    private boolean awayTeamSubSelected;
    
    private boolean liberoInToggle;
            
    private boolean possession; //Team 2- False. Team 1- True
    
    private ArrayList<Player> playerLog;
    private ArrayList<String> actionLog;
    
    
    private Player team1Starters[];
    private Player team2Starters[];
    private Player team1[];
    private Player team2[];
    private Player dummy;
    
          
    
    public Volley()
    {
        serveTrack = new DoubleLinkedListSideOutTracker();
        contactCounter = 0;
        
        firstButtonPressedToggle = false;
        continueToggle = false;
        overToggle = false;
        
        errorToggle = false;
        
        blockToggle = false;
        blockTypeChosen = false;
        blockerChosen = false;
        soloBlockOn = false;
        blockAssistOnDouble = false;
        blockAssistOnTriple = false;
        MHBlockOn = false;
        OHBlockOn = false;
        OPPBlockOn = false;
        OHBackBlockOn = false;
        LiberoBlockOn = false;
        SetterBlockOn = false;
        
        substitutionToggleOn = false;
        subEnterToggle = false;
        substitutionNumber = 0;
        teamSubSelect = false;
        homeTeamSubSelected = false;
        awayTeamSubSelected = false;
        
        liberoInToggle = true;
        
        possession = true;
        
        playerLog = new ArrayList(0);
        actionLog = new ArrayList(0);
        
        
        team1Starters = new Player[8];
        team2Starters = new Player[8];
        team1 = new Player[30];
        team2 = new Player[30];
        dummy = new Player();
        
    }
    
    public void init()
    {
        this.addKeyListener(this);
    }
    
    public void createRoster()
    {
        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();
        Player p4 = new Player();
        Player p5 = new Player();
        Player p6 = new Player();
        Player p7 = new Player();
        Player p8 = new Player();
        Player p9 = new Player();
        Player p10 = new Player();
        Player p11 = new Player();
        Player p12 = new Player();
        Player p13 = new Player();
        Player p14 = new Player();
        Player p15 = new Player();
        Player p16 = new Player();
        Player p17 = new Player();
        Player p18 = new Player();
        Player p19 = new Player();
        Player p20 = new Player();
        Player p21 = new Player();
        Player p22 = new Player();
        Player p23 = new Player();
        Player p24 = new Player();
        Player p25 = new Player();
        Player p26 = new Player();
        Player p27 = new Player();
        Player p28 = new Player();
        Player p29 = new Player();
        Player p30 = new Player();
        Player p31 = new Player();
        Player p32 = new Player();
        Player p33 = new Player();
        Player p34 = new Player();
        Player p35 = new Player();
        Player p36 = new Player();
        Player p37 = new Player();
        Player p38 = new Player();
        Player p39 = new Player();
        Player p40 = new Player();
        Player p41 = new Player();
        Player p42 = new Player();
        Player p43 = new Player();
        Player p44 = new Player();
        Player p45 = new Player();
        Player p46 = new Player();
        Player p47 = new Player();
        Player p48 = new Player();
        Player p49 = new Player();
        Player p50 = new Player();
        Player p51 = new Player();
        Player p52 = new Player();
        Player p53 = new Player();
        Player p54 = new Player();
        Player p55 = new Player();
        Player p56 = new Player();
        Player p57 = new Player();
        Player p58 = new Player();
        Player p59 = new Player();
        Player p60 = new Player();
        
        team1[0] = p1;
        team1[1] = p2;
        team1[2] = p3;
        team1[3] = p4;
        team1[4] = p5;
        team1[5] = p6;
        team1[6] = p7;
        team1[7] = p8;
        team1[8] = p9;
        team1[9] = p10;
        team1[10] = p11;
        team1[11] = p12;
        team1[12] = p13;
        team1[13] = p14;
        team1[14] = p15;
        team1[15] = p16;
        team1[16] = p17;
        team1[17] = p18;
        team1[18] = p19;
        team1[19] = p20;
        team1[20] = p21;
        team1[21] = p22;
        team1[22] = p23;
        team1[23] = p24;
        team1[24] = p25;
        team1[25] = p26;
        team1[26] = p27;
        team1[27] = p28;
        team1[28] = p29;
        team1[29] = p30;
        
        team2[0] = p31;
        team2[1] = p32;
        team2[2] = p33;
        team2[3] = p34;
        team2[4] = p35;
        team2[5] = p36;
        team2[6] = p37;
        team2[7] = p38;
        team2[8] = p39;
        team2[9] = p40;
        team2[10] = p41;
        team2[11] = p42;
        team2[12] = p43;
        team2[13] = p44;
        team2[14] = p45;
        team2[15] = p46;
        team2[16] = p47;
        team2[17] = p48;
        team2[18] = p49;
        team2[19] = p50;
        team2[20] = p51;
        team2[21] = p52;
        team2[22] = p53;
        team2[23] = p54;
        team2[24] = p55;
        team2[25] = p56;
        team2[26] = p57;
        team2[27] = p58;
        team2[28] = p59;
        team2[29] = p60;
    }
    
    public int chooseTeam()
    {
        //Which Team
        Scanner enter = new Scanner(System.in);
        
        int num=0;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter which team (1 or 2)"); 
            try
            {
                num = enter.nextInt();
                pass = true;
                
                if(num<1 || num>2)
                {
                    pass = false;
                    System.out.println("Number is not 1 or 2. Reboot");
                }
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//while
        return num;
    }
    
    public void createPlayer()
    {  
        if(chooseTeam()==1)
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    return;
                }
            }
        }
        else
        {
            for(int i=0; i<30; i++)
            {
                if(team2[i].getPlayerName().equals(""))
                {
                    team2[i].setPlayerName();
                    team2[i].setPlayerNumber();
                    return;
                }
            }
        }
    }//create Player

    
    public void establishSetter()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the setter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[1] = team1[i];
                            team1Starters[1].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot1");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[1] = team2[i];
                            team2Starters[1].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot2");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishSetter
    
    public void establishOH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 2 (Following Setter)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[2] = team1[i];
                            team1Starters[2].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot3");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[2] = team2[i];
                            team2Starters[2].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot4");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH2
    
    public void establishMH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 2 (Follows OH2)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[3] = team1[i];
                            team1Starters[3].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[3] = team2[i];
                            team2Starters[3].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH2
    
    public void establishOP()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Opposite Hitter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[4] = team1[i];
                            team1Starters[4].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[4] = team2[i];
                            team2Starters[4].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOP
    
    public void establishOH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 1(Follows Opposite)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[5] = team1[i];
                            team1Starters[5].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[5] = team2[i];
                            team2Starters[5].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH1
    
    public void establishMH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 1"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[6] = team1[i];
                            team1Starters[6].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[6] = team2[i];
                            team2Starters[6].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH1
    
    public void establishLibero()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Starting Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[0] = team1[i];
                            team1Starters[0].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[0] = team2[i];
                            team2Starters[0].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLibero
    
    public void establishLiberoR()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Reserved Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[7] = team1[i];
                            team1Starters[7].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[7] = team2[i];
                            team2Starters[7].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLiberoR
    
    public void rotate()
    {
        if(serveTrack.last.prev.prev == serveTrack.last.prev)
        {
            return;
        }
        else if(possession)
        {
            team1Starters[0].rotatePosition();
            team1Starters[1].rotatePosition();
            team1Starters[2].rotatePosition();
            team1Starters[3].rotatePosition();
            team1Starters[4].rotatePosition();
            team1Starters[5].rotatePosition();
            team1Starters[6].rotatePosition();
            team1Starters[7].rotatePosition();
        }
        else
        {
            team2Starters[0].rotatePosition();
            team2Starters[1].rotatePosition();
            team2Starters[2].rotatePosition();
            team2Starters[3].rotatePosition();
            team2Starters[4].rotatePosition();
            team2Starters[5].rotatePosition();
            team2Starters[6].rotatePosition();
            team2Starters[7].rotatePosition();
        }
    }
    
    public int getContactCounter()
    {
        return contactCounter;
    }
    
    public void createTeamsForTesting()
    {
        team1[0].name = "T1Setter";
        team1[0].number = 1;
        team1[1].name = "T1OH2";
        team1[1].number = 2;
        team1[2].name = "T1MH2";
        team1[2].number = 3;
        team1[3].name = "T1Oppo";
        team1[3].number = 4;
        team1[4].name = "T1OH1";
        team1[4].number = 5;
        team1[5].name = "T1MH1";
        team1[5].number = 6;
        team1[6].name = "T1Libero";
        team1[6].number = 7; 
        team1[7].name = "T1LiberoR";
        team1[7].number = 8;
        
        team1Starters[1] = team1[0];
        team1Starters[1].position = 1;
        team1Starters[2] = team1[1];
        team1Starters[2].position = 2;
        team1Starters[3] = team1[2];
        team1Starters[3].position = 3;
        team1Starters[4] = team1[3];
        team1Starters[4].position = 4;
        team1Starters[5] = team1[4];
        team1Starters[5].position = 5;
        team1Starters[6] = team1[5];
        team1Starters[6].position = 6;
        team1Starters[0] = team1[6];
        team1Starters[0].position = 6;
        team1Starters[7] = team1[7];
        team1Starters[7].position = 6;
        
        
        team2[0].name = "T2Setter";
        team2[0].number = 1;
        team2[1].name = "T2OH2";
        team2[1].number = 2;
        team2[2].name = "T2MH2";
        team2[2].number = 3;
        team2[3].name = "T2Oppo";
        team2[3].number = 4;
        team2[4].name = "T2OH1";
        team2[4].number = 5;
        team2[5].name = "T2MH1";
        team2[5].number = 6;
        team2[6].name = "T2Libero";
        team2[6].number = 7; 
        team2[7].name = "T2LiberoR";
        team2[7].number = 8;
        
        team2Starters[1] = team2[0];
        team2Starters[1].position = 1;
        team2Starters[2] = team2[1];
        team2Starters[2].position = 2;
        team2Starters[3] = team2[2];
        team2Starters[3].position = 3;
        team2Starters[4] = team2[3];
        team2Starters[4].position = 4;
        team2Starters[5] = team2[4];
        team2Starters[5].position = 5;
        team2Starters[6] = team2[5];
        team2Starters[6].position = 6;
        team2Starters[0] = team2[6];
        team2Starters[0].position = 6;
        team2Starters[7] = team2[7];
        team2Starters[7].position = 6;
        
    }
    
    public void updateActionWindow()
    { 
        String actionLine = "";
        for(int i=0; i<playerLog.size(); i++)
        {
            actionLine = actionLine + playerLog.get(i).getPlayerName() + " " + playerLog.get(i).getPlayerPosition() + " " + actionLog.get(i) + "\n";
        }
        getActionWindow().setText(actionLine);
    }
    
    
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`    
    @Override
    public void keyPressed(KeyEvent e)
    {
        //1-Middle Hitter
        if(e.getKeyCode() == KeyEvent.VK_Q)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    MHBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }
            //So a person does not hit attack button before a player is pressed.
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            updateActionWindow();
            
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            }       
        }//End of middle hitter
    
        //2-Outside Hitter
        else if(e.getKeyCode() == KeyEvent.VK_W)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }//iffirsttoggle
            
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? OH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter
        //3-Opposite Hitter
        else if(e.getKeyCode() == KeyEvent.VK_E)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OPPBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("x");
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Opposite
        //4-Outside Hitter (Back Row)
        else if(e.getKeyCode() == KeyEvent.VK_R)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    OHBackBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                    }  
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter (Back Row)
        //5-Libero
        else if(e.getKeyCode() == KeyEvent.VK_T)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    LiberoBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        if(liberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(liberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if(liberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(liberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(liberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }// End of Libero
        //6-Setter
        else if(e.getKeyCode() == KeyEvent.VK_Y)
        {
            if(blockToggle)
            {
                if(!blockerChosen)
                {
                    blockerChosen = true;
                    SetterBlockOn = true;
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Setter
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
        
        //7-Attack
        else if(e.getKeyCode() == KeyEvent.VK_U)
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0) //When play is over turn it off
            {
                //firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "attack");
                updateActionWindow();
                contactCounter = 0;
                possession = !possession;
            }
        }
        //8-Over
        else if(e.getKeyCode() == KeyEvent.VK_I)
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0) //When play is over turn it off
            {
                //firstButtonPressedToggle=false;
                overToggle = true;
                contactCounter = 0;
                possession = !possession;
            }
        }
        //9-Continue
        else if(e.getKeyCode() == KeyEvent.VK_O)
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0)
            {
                //firstButtonPressedToggle=false;
                continueToggle = true;
                contactCounter = 0;
            }
        }
        //10-Kill
        else if(e.getKeyCode() == KeyEvent.VK_P)
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "kill");
                if(actionLog.get(actionLog.size()-2).equals("dig"))
                {
                    actionLog.set(actionLog.size()-2, "dig&assist");
                }
                else
                {
                    actionLog.set(actionLog.size()-2, "assist");
                }
                updateActionWindow();
                contactCounter = 0;
                possession=!possession;
                rotate();
            }
        }
        //11-Block
        else if(e.getKeyCode() == KeyEvent.VK_A)
        {
            if(!firstButtonPressedToggle)
            {
                return;
            }
            
            actionLog.add("InCaseOfBlockError");
            playerLog.add(dummy);
            
            
            firstButtonPressedToggle=false;
            boolean trapWhile = true;
            blockToggle=true;
            System.out.println("How many blockers?");
            while(trapWhile)
            {
                if(soloBlockOn)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("soloBlock");
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                            //Team 2
                        else
                        {
                            if(liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("soloBlock");
                        }
                        SetterBlockOn = false;
                    }
                    soloBlockOn = false;
                    blockTypeChosen = false;
                    blockerChosen = false;
                    return;
                }
                if(blockAssistOnDouble)
                {
                    int miniActionLogCounter = 0;
                    Player BlockPlayerLog[] = new Player[2];
                    String BlockActionLog[] = new String[2];
                    
                    while(miniActionLogCounter<=1)
                    {
                        if(MHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            MHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? OH2
                                if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OPPBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                       
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            OPPBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBackBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBackBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(LiberoBlockOn)
                        {
                            if(possession)
                            {
                                if(liberoInToggle)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[0];
                                    BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                }
                                else
                                {
                                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team1Starters[3];
                                        BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                    }
                                    //MH1
                                    else
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team1Starters[6];
                                        BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                    }
                                }
                            }
                                //Team 2
                            else
                            {
                                if(liberoInToggle)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[0];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team2Starters[3];
                                        BlockActionLog[miniActionLogCounter]="soloBlock";
                                    }
                                    //MH1
                                    else
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team2Starters[6];
                                        BlockActionLog[miniActionLogCounter]="soloBlock";
                                    }
                                }
                            }
                            LiberoBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(SetterBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                    
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            SetterBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        if(miniActionLogCounter == 2)
                        {
                            if(BlockPlayerLog[0]==BlockPlayerLog[1])
                            {
                                System.out.println("A block assist consist of two different players blocking to earn a point and end the rally."
                                        + "You entered the same player twice. Did you mean for a soloBlock? Entering yes will give a solo block to the player you entered twice."
                                        + "Entering no will reset you to Block Assist-Then enter two different players");
                                miniActionLogCounter = 0;
                                BlockPlayerLog = new Player[2];
                                BlockActionLog = new String[2];
                            }
                            else
                            {
                                playerLog.add(BlockPlayerLog[0]);
                                actionLog.add(BlockActionLog[0]);
                                
                                playerLog.add(BlockPlayerLog[1]);
                                actionLog.add(BlockActionLog[1]);
                            }
                        }
                    }//while two
                    blockAssistOnDouble = false;
                    blockTypeChosen = false;
                    return;
                }//if blockAssist
                if(blockAssistOnTriple)
                {
                    int miniActionLogCounter = 0;
                    Player BlockPlayerLog[] = new Player[3];
                    String BlockActionLog[] = new String[3];
                    
                    while(miniActionLogCounter<=1)
                    {
                        if(MHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[3];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[6];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            MHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? OH2
                                if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OPPBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                       
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[4];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            OPPBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(OHBackBlockOn)
                        {
                            if(possession)
                            {
                                //Which Middle hitter is receiving credit? MH2
                                if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                //MH1
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            //Team 2
                            else
                            {
                                if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[5];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[2];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                            }
                            OHBackBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(LiberoBlockOn)
                        {
                            if(possession)
                            {
                                if(liberoInToggle)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team1Starters[0];
                                    BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                }
                                else
                                {
                                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team1Starters[3];
                                        BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                    }
                                    //MH1
                                    else
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team1Starters[6];
                                        BlockActionLog[miniActionLogCounter]="soloBlock"; 
                                    }
                                }
                            }
                                //Team 2
                            else
                            {
                                if(liberoInToggle)
                                {
                                    BlockPlayerLog[miniActionLogCounter]=team2Starters[0];
                                    BlockActionLog[miniActionLogCounter]="soloBlock";
                                }
                                else
                                {
                                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team2Starters[3];
                                        BlockActionLog[miniActionLogCounter]="soloBlock";
                                    }
                                    //MH1
                                    else
                                    {
                                        BlockPlayerLog[miniActionLogCounter]=team2Starters[6];
                                        BlockActionLog[miniActionLogCounter]="soloBlock";
                                    }
                                }
                            }
                            LiberoBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        else if(SetterBlockOn)
                        {
                            if(possession)
                            {
                                BlockPlayerLog[miniActionLogCounter]=team1Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";                    
                            }
                            //Team 2
                            else
                            {
                                BlockPlayerLog[miniActionLogCounter]=team2Starters[1];
                                BlockActionLog[miniActionLogCounter]="soloBlock";
                            }
                            SetterBlockOn = false;
                            blockerChosen = false;
                            miniActionLogCounter++;
                        }
                        if(miniActionLogCounter == 3)
                        {
                            if(BlockPlayerLog[0]==BlockPlayerLog[1] || BlockPlayerLog[0]==BlockPlayerLog[2] || BlockPlayerLog[1]==BlockPlayerLog[2])
                            {
                                System.out.println("A block assist consist of different players blocking to earn a point and end the rally."
                                        + "You entered the same player twice. Did you mean for a soloBlock? TRY AGIAN. It would be nice if--Entering yes will give a solo block to the player you entered twice."
                                        + "Entering no will reset you to Block Assist-Then enter two different players");
                                miniActionLogCounter = 0;
                                BlockPlayerLog = new Player[2];
                                BlockActionLog = new String[2];
                            }
                            else
                            {
                                playerLog.add(BlockPlayerLog[0]);
                                actionLog.add(BlockActionLog[0]);
                                
                                playerLog.add(BlockPlayerLog[1]);
                                actionLog.add(BlockActionLog[1]);
                            }
                        }
                    }//while two
                    blockAssistOnTriple = false;
                    blockTypeChosen = false;
                    return;
                }//if blockAssistTriple
            }//whileTrap
            updateActionWindow();
            rotate();
            blockToggle=false;
        }
        //12-Error
        else if(e.getKeyCode() == KeyEvent.VK_S)
        {
            //Service Error
            if(!firstButtonPressedToggle && !blockToggle)
            {
                errorToggle = true;
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                
                            }
                            if(i==6 && liberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                rotate();
            }
            //Reception Error, Ball Handling Error, Attack Error, and blockError
            else //if(firstButtonPressedToggle && !blockToggle)
            {
                if(actionLog.get(actionLog.size()-1).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-1,"receptionError");
                }
                else if(actionLog.get(actionLog.size()-1).equals("zeroAssist") || actionLog.get(actionLog.size()-1).equals("dig") || actionLog.get(actionLog.size()-1).equals("x"))
                {
                    actionLog.set(actionLog.size()-1,"ballHandlingError");
                }
                else if(actionLog.get(actionLog.size()-1).equals("attack"))
                {
                    actionLog.set(actionLog.size()-1,"attackError");
                }
                else
                {
                    boolean trapWhile = true;
                    blockToggle=true;
                    while(trapWhile)
                    {
                        if(soloBlockOn)
                        {
                            if(MHBlockOn)
                            {
                                if(possession)
                                {
                                    //Which Middle hitter is receiving credit? MH2
                                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[3]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    //MH1
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[6]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                //Team 2
                                else
                                {
                                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[3]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[6]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                MHBlockOn = false;
                            }
                            else if(OHBlockOn)
                            {
                                if(possession)
                                {
                                    //Which Middle hitter is receiving credit? OH2
                                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[2]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    //MH1
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[5]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                //Team 2
                                else
                                {
                                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[2]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[5]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                OHBlockOn = false;
                            }
                            else if(OPPBlockOn)
                            {
                                if(possession)
                                {
                                    playerLog.set(actionLog.size()-1,team1Starters[4]);
                                    actionLog.set(actionLog.size()-1,"blockError");                      
                                }
                                //Team 2
                                else
                                {
                                    playerLog.set(actionLog.size()-1,team2Starters[4]);
                                    actionLog.set(actionLog.size()-1,"blockError");
                                }
                                OPPBlockOn = false;
                            }
                            else if(OHBackBlockOn)
                            {
                                if(possession)
                                {
                                    //Which Middle hitter is receiving credit? MH2
                                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[5]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    //MH1
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[2]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                //Team 2
                                else
                                {
                                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[5]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    else
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[2]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                }
                                OHBackBlockOn = false;
                            }
                            else if(LiberoBlockOn)
                            {
                                if(possession)
                                {
                                    if(liberoInToggle)
                                    {
                                        playerLog.set(actionLog.size()-1,team1Starters[0]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    else
                                    {
                                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                        {
                                            playerLog.set(actionLog.size()-1,team1Starters[3]);
                                            actionLog.set(actionLog.size()-1,"blockError");
                                        }
                                        //MH1
                                        else
                                        {
                                            playerLog.set(actionLog.size()-1,team1Starters[6]);
                                            actionLog.set(actionLog.size()-1,"blockError");
                                        }
                                    }
                                }
                                    //Team 2
                                else
                                {
                                    if(liberoInToggle)
                                    {
                                        playerLog.set(actionLog.size()-1,team2Starters[0]);
                                        actionLog.set(actionLog.size()-1,"blockError");
                                    }
                                    else
                                    {
                                       if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                        {
                                            playerLog.set(actionLog.size()-1,team2Starters[3]);
                                            actionLog.set(actionLog.size()-1,"blockError");
                                        }
                                        //MH1
                                        else
                                        {
                                            playerLog.set(actionLog.size()-1,team2Starters[6]);
                                            actionLog.set(actionLog.size()-1,"blockError");
                                        }
                                    }
                                }
                                LiberoBlockOn = false;
                            }
                            else if(SetterBlockOn)
                            {
                                if(possession)
                                {
                                    playerLog.set(actionLog.size()-1,team1Starters[1]);
                                    actionLog.set(actionLog.size()-1,"blockError");                       
                                }
                                //Team 2
                                else
                                {
                                    playerLog.set(actionLog.size()-1,team2Starters[1]);
                                    actionLog.set(actionLog.size()-1,"blockError");
                                }
                                SetterBlockOn = false;
                            }
                            soloBlockOn = false;
                            blockTypeChosen = false;
                            blockerChosen = false;
                            return;
                        }
                    }//while
                }//block
                updateActionWindow();
                rotate();
            }//the quadrouple.
        }//error
        //13-Substitution
        else if(e.getKeyCode() == KeyEvent.VK_D)
        {
            if(!blockToggle && contactCounter==0)
            {
                Player temp[] = new Player[1]; 
                boolean whichTeam=true;
                int playerComingInPosition=0;
                int in = 0;
                int out = 0;
                substitutionToggleOn = true;
                teamSubSelect = true;
                substitutionNumber = 0;
                System.out.println("Which Team?");
                while(teamSubSelect)
                {
                    if(homeTeamSubSelected)
                    {
                        whichTeam = true;
                        break;
                    }
                    else if(awayTeamSubSelected)
                    {
                        whichTeam = false;
                        break;
                    }
                }
                System.out.println("Player coming IN");
                while(!subEnterToggle)
                {
                    
                }
                in = substitutionNumber;
                subEnterToggle = false;
                substitutionNumber = 0;
                System.out.println("Player coming OUT");
                while(!subEnterToggle)
                {
                    
                }
                out = substitutionNumber;
                subEnterToggle = false;
                
                if(whichTeam)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == in)
                        {
                            temp[0]=team1[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerNumber() == out)
                        {
                            team1[playerComingInPosition]=team1Starters[i];
                            team1Starters[i]=temp[0];
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == in)
                        {
                            temp[0]=team2[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerNumber() == out)
                        {
                            team2[playerComingInPosition]=team2Starters[i];
                            team2Starters[i]=temp[0];
                        }
                    }
                }
            }
        }
        //14-Back
        else if(e.getKeyCode() == KeyEvent.VK_F)
        {
            
        }
        //15-Skip
        else if(e.getKeyCode() == KeyEvent.VK_G)
        {
            
        }
        //16-Enter
        else if(e.getKeyCode() == KeyEvent.VK_H)
        {
            
        }
        //16-SoloBlock
        else if(e.getKeyCode() == KeyEvent.VK_J)
        {
            System.out.println("SUP NIGGER");
            if(blockToggle && !blockTypeChosen)
            {
                soloBlockOn=true;
            }
        }
        //16-BlockAssistDouble
        else if(e.getKeyCode() == KeyEvent.VK_K)
        {
            if(blockToggle && !blockTypeChosen)
            {
                blockAssistOnDouble=true;
            }
        }
        //16-BlockAssistTriple
        else if(e.getKeyCode() == KeyEvent.VK_N)
        {
            if(blockToggle && !blockTypeChosen)
            {
                blockAssistOnTriple=true;
            }
        }
        //17-LiberoInToggle
        else if(e.getKeyCode() == KeyEvent.VK_L)
        {
            liberoInToggle=!liberoInToggle;
        }
        //18-SubIncreaseNum+1
        else if(e.getKeyCode() == KeyEvent.VK_Z)
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    homeTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber++;
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-1
        else if(e.getKeyCode() == KeyEvent.VK_X)
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    awayTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber--;
                System.out.println("substitutionNumber");
            }
        }
        //18-SubIncreaseNum+10
        else if(e.getKeyCode() == KeyEvent.VK_C)
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-10
        else if(e.getKeyCode() == KeyEvent.VK_V)
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //EnterSub
        else if(e.getKeyCode() == KeyEvent.VK_B)
        {
            if(substitutionToggleOn)
            {
                subEnterToggle = true;
            }
        }
            
    }
        

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}   */


/*
container = getContentPane();
        container.setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setVisible(true);
        setLayout(new FlowLayout()); 
        
        actionWindow = new JTextArea(20, 20);
        actionWindow.setEditable(false);
        actionWindow.setFocusable(false);
        JScrollPane scrollPaneDAW = new JScrollPane(actionWindow);
        add(scrollPaneDAW);
        
        
        promptWindow = new JTextArea(20, 20);
        promptWindow.setEditable(false);
        promptWindow.setFocusable(false);
        JScrollPane scrollPanePW = new JScrollPane(promptWindow);
        add(scrollPanePW);
        
        //panel = getPanel();
        //panel.setFocusable(true);*/

/*package alu;

import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */
/*
public class Volley extends Player implements KeyListener
{
    private DoubleLinkedListSideOutTracker serveTrack;
    private int contactCounter;
    private int team1Score;
    private int team2Score;
    
    private boolean firstButtonPressedToggle;
    private boolean continueToggle;
    private boolean overToggle;
    
    private boolean errorToggle;
    
    private boolean blockToggle;
    private boolean blockTypeChosen;
    private boolean blockerChosen;
    private boolean soloBlockOn;
    private boolean blockAssistOnDouble;
    private boolean blockAssistOnTriple;
    private boolean MHBlockOn;
    private boolean OHBlockOn;
    private boolean OPPBlockOn;
    private boolean OHBackBlockOn;
    private boolean LiberoBlockOn;
    private boolean SetterBlockOn;
    private int blockerCount;
    private boolean blockErrorToggle;
    
    private boolean substitutionToggleOn;
    private boolean subEnterToggle;
    private int substitutionNumber;
    private boolean teamSubSelect;
    private boolean homeTeamSubSelected;
    private boolean awayTeamSubSelected;
    
    private boolean team1LiberoInToggle;
    private boolean team2LiberoInToggle;
            
    private boolean possession; //Team 2- False. Team 1- True
    
    private ArrayList<Player> playerLog;
    private ArrayList<String> actionLog;
    
    
    private Player team1Starters[];
    private Player team2Starters[];
    private Player team1[];
    private Player team2[];
    private Player dummy;
    
          
    
    public Volley()
    {
        serveTrack = new DoubleLinkedListSideOutTracker();
        contactCounter = 0;
        team1Score = 0;
        team2Score = 0;
        
        firstButtonPressedToggle = false;
        continueToggle = false;
        overToggle = false;
        
        errorToggle = false;
        
        blockToggle = false;
        blockTypeChosen = false;
        blockerChosen = false;
        soloBlockOn = false;
        blockAssistOnDouble = false;
        blockAssistOnTriple = false;
        MHBlockOn = false;
        OHBlockOn = false;
        OPPBlockOn = false;
        OHBackBlockOn = false;
        LiberoBlockOn = false;
        SetterBlockOn = false;
        blockerCount = 0;
        blockErrorToggle = false;
        
        substitutionToggleOn = false;
        subEnterToggle = false;
        substitutionNumber = 0;
        teamSubSelect = false;
        homeTeamSubSelected = false;
        awayTeamSubSelected = false;
        
        team1LiberoInToggle = true;
        team2LiberoInToggle = true;
        
        possession = true;
        
        playerLog = new ArrayList(0);
        actionLog = new ArrayList(0);
        
        
        team1Starters = new Player[8];
        team2Starters = new Player[8];
        team1 = new Player[31];
        team2 = new Player[31];
        dummy = new Player();
        
    }
    
    public void init()
    {
        this.addKeyListener(this);
    }
    
    public void createRoster()
    {
        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();
        Player p4 = new Player();
        Player p5 = new Player();
        Player p6 = new Player();
        Player p7 = new Player();
        Player p8 = new Player();
        Player p9 = new Player();
        Player p10 = new Player();
        Player p11 = new Player();
        Player p12 = new Player();
        Player p13 = new Player();
        Player p14 = new Player();
        Player p15 = new Player();
        Player p16 = new Player();
        Player p17 = new Player();
        Player p18 = new Player();
        Player p19 = new Player();
        Player p20 = new Player();
        Player p21 = new Player();
        Player p22 = new Player();
        Player p23 = new Player();
        Player p24 = new Player();
        Player p25 = new Player();
        Player p26 = new Player();
        Player p27 = new Player();
        Player p28 = new Player();
        Player p29 = new Player();
        Player p30 = new Player();
        Player p31 = new Player();
        Player p32 = new Player();
        Player p33 = new Player();
        Player p34 = new Player();
        Player p35 = new Player();
        Player p36 = new Player();
        Player p37 = new Player();
        Player p38 = new Player();
        Player p39 = new Player();
        Player p40 = new Player();
        Player p41 = new Player();
        Player p42 = new Player();
        Player p43 = new Player();
        Player p44 = new Player();
        Player p45 = new Player();
        Player p46 = new Player();
        Player p47 = new Player();
        Player p48 = new Player();
        Player p49 = new Player();
        Player p50 = new Player();
        Player p51 = new Player();
        Player p52 = new Player();
        Player p53 = new Player();
        Player p54 = new Player();
        Player p55 = new Player();
        Player p56 = new Player();
        Player p57 = new Player();
        Player p58 = new Player();
        Player p59 = new Player();
        Player p60 = new Player();
        Player team1Collect = new Player();
        Player team2Collect = new Player();
        
        team1[0] = p1;
        team1[1] = p2;
        team1[2] = p3;
        team1[3] = p4;
        team1[4] = p5;
        team1[5] = p6;
        team1[6] = p7;
        team1[7] = p8;
        team1[8] = p9;
        team1[9] = p10;
        team1[10] = p11;
        team1[11] = p12;
        team1[12] = p13;
        team1[13] = p14;
        team1[14] = p15;
        team1[15] = p16;
        team1[16] = p17;
        team1[17] = p18;
        team1[18] = p19;
        team1[19] = p20;
        team1[20] = p21;
        team1[21] = p22;
        team1[22] = p23;
        team1[23] = p24;
        team1[24] = p25;
        team1[25] = p26;
        team1[26] = p27;
        team1[27] = p28;
        team1[28] = p29;
        team1[29] = p30;
        team1[30] = team1Collect;
        
        team2[0] = p31;
        team2[1] = p32;
        team2[2] = p33;
        team2[3] = p34;
        team2[4] = p35;
        team2[5] = p36;
        team2[6] = p37;
        team2[7] = p38;
        team2[8] = p39;
        team2[9] = p40;
        team2[10] = p41;
        team2[11] = p42;
        team2[12] = p43;
        team2[13] = p44;
        team2[14] = p45;
        team2[15] = p46;
        team2[16] = p47;
        team2[17] = p48;
        team2[18] = p49;
        team2[19] = p50;
        team2[20] = p51;
        team2[21] = p52;
        team2[22] = p53;
        team2[23] = p54;
        team2[24] = p55;
        team2[25] = p56;
        team2[26] = p57;
        team2[27] = p58;
        team2[28] = p59;
        team2[29] = p60;
        team2[30] = team2Collect;
    }
    
    public int chooseTeam()
    {
        //Which Team
        Scanner enter = new Scanner(System.in);
        
        int num=0;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter which team (1 or 2)"); 
            try
            {
                num = enter.nextInt();
                pass = true;
                
                if(num<1 || num>2)
                {
                    pass = false;
                    System.out.println("Number is not 1 or 2. Reboot");
                }
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//while
        return num;
    }
    
    public void createPlayer()
    {  
        if(chooseTeam()==1)
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    return;
                }
            }
        }
        else
        {
            for(int i=0; i<30; i++)
            {
                if(team2[i].getPlayerName().equals(""))
                {
                    team2[i].setPlayerName();
                    team2[i].setPlayerNumber();
                    return;
                }
            }
        }
    }//create Player

    
    public void establishSetter()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the setter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[1] = team1[i];
                            team1Starters[1].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot1");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[1] = team2[i];
                            team2Starters[1].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot2");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishSetter
    
    public void establishOH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 2 (Following Setter)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[2] = team1[i];
                            team1Starters[2].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot3");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[2] = team2[i];
                            team2Starters[2].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot4");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH2
    
    public void establishMH2()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 2 (Follows OH2)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[3] = team1[i];
                            team1Starters[3].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[3] = team2[i];
                            team2Starters[3].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH2
    
    public void establishOP()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Opposite Hitter"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[4] = team1[i];
                            team1Starters[4].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[4] = team2[i];
                            team2Starters[4].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOP
    
    public void establishOH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Outside Hitter 1(Follows Opposite)"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[5] = team1[i];
                            team1Starters[5].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[5] = team2[i];
                            team2Starters[5].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishOH1
    
    public void establishMH1()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Middle Hitter 1"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[6] = team1[i];
                            team1Starters[6].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[6] = team2[i];
                            team2Starters[6].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishMH1
    
    public void establishLibero()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Starting Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[0] = team1[i];
                            team1Starters[0].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[0] = team2[i];
                            team2Starters[0].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLibero
    
    public void establishLiberoR()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter the number of the Reserved Libero"); 
            try
            {
                num = enter.nextInt();
                
                if(chooseTeam() == 1)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == num)
                        {
                            team1Starters[7] = team1[i];
                            team1Starters[7].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == num)
                        {
                            team2Starters[7] = team2[i];
                            team2Starters[7].setPlayerPosition();
                            return;
                        }
                        else if(i==29)
                        {
                            System.out.println("A player with that number was never created. Reboot");
                            pass = false;
                        }
                    }
                }   
            }//try
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//While   
    }//EstablishLiberoR
    
    public void rotate()
    {
        if(serveTrack.last.prev.prev.data == serveTrack.last.prev.data)
        {
            return;
        }
        else if(possession)
        {
            team1Starters[0].rotatePosition();
            team1Starters[1].rotatePosition();
            team1Starters[2].rotatePosition();
            team1Starters[3].rotatePosition();
            team1Starters[4].rotatePosition();
            team1Starters[5].rotatePosition();
            team1Starters[6].rotatePosition();
            team1Starters[7].rotatePosition();
        }
        else
        {
            team2Starters[0].rotatePosition();
            team2Starters[1].rotatePosition();
            team2Starters[2].rotatePosition();
            team2Starters[3].rotatePosition();
            team2Starters[4].rotatePosition();
            team2Starters[5].rotatePosition();
            team2Starters[6].rotatePosition();
            team2Starters[7].rotatePosition();
        }
    }
    
    public int getContactCounter()
    {
        return contactCounter;
    }
    
    public void createTeamsForTesting()
    {
        serveTrack.insert(1);
        
        team1[0].name = "T1Setter";
        team1[0].number = 1;
        team1[1].name = "T1OH2";
        team1[1].number = 2;
        team1[2].name = "T1MH2";
        team1[2].number = 3;
        team1[3].name = "T1Oppo";
        team1[3].number = 4;
        team1[4].name = "T1OH1";
        team1[4].number = 5;
        team1[5].name = "T1MH1";
        team1[5].number = 6;
        team1[6].name = "T1Libero";
        team1[6].number = 7; 
        team1[7].name = "T1LiberoR";
        team1[7].number = 8;
        
        team1Starters[1] = team1[0];
        team1Starters[1].position = 1;
        team1Starters[2] = team1[1];
        team1Starters[2].position = 2;
        team1Starters[3] = team1[2];
        team1Starters[3].position = 3;
        team1Starters[4] = team1[3];
        team1Starters[4].position = 4;
        team1Starters[5] = team1[4];
        team1Starters[5].position = 5;
        team1Starters[6] = team1[5];
        team1Starters[6].position = 6;
        team1Starters[0] = team1[6];
        team1Starters[0].position = 6;
        team1Starters[7] = team1[7];
        team1Starters[7].position = 6;
        
        
        team2[0].name = "T2Setter";
        team2[0].number = 1;
        team2[1].name = "T2OH2";
        team2[1].number = 2;
        team2[2].name = "T2MH2";
        team2[2].number = 3;
        team2[3].name = "T2Oppo";
        team2[3].number = 4;
        team2[4].name = "T2OH1";
        team2[4].number = 5;
        team2[5].name = "T2MH1";
        team2[5].number = 6;
        team2[6].name = "T2Libero";
        team2[6].number = 7; 
        team2[7].name = "T2LiberoR";
        team2[7].number = 8;
        
        team2Starters[1] = team2[0];
        team2Starters[1].position = 1;
        team2Starters[2] = team2[1];
        team2Starters[2].position = 2;
        team2Starters[3] = team2[2];
        team2Starters[3].position = 3;
        team2Starters[4] = team2[3];
        team2Starters[4].position = 4;
        team2Starters[5] = team2[4];
        team2Starters[5].position = 5;
        team2Starters[6] = team2[5];
        team2Starters[6].position = 6;
        team2Starters[0] = team2[6];
        team2Starters[0].position = 6;
        team2Starters[7] = team2[7];
        team2Starters[7].position = 6;
        
    }
    
    public void updateActionWindow()
    { 
        String actionLine = "";
        for(int i=0; i<playerLog.size(); i++)
        {
            actionLine = actionLine + playerLog.get(i).getPlayerName() + " " + playerLog.get(i).getPlayerPosition() + " " + actionLog.get(i) + "\n";
        }
        getActionWindow().setText(actionLine);
    }
    
    public void whoServesFirst()
    {
        if(chooseTeam()==1)
        {
            serveTrack.insert(1);
        }
        else
        {
            serveTrack.insert(0);
        }
    }
    
    
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`    
    @Override
    public void keyPressed(KeyEvent e)
    {
        //1-Middle Hitter
        if(e.getKeyCode() == KeyEvent.VK_Q)
        {
            if(blockToggle)
            {
                if(MHBlockOn)
                {
                    blockerCount--;
                    MHBlockOn = false;
                    System.out.println("MHBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    MHBlockOn = true;
                    System.out.println("MHBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }
            //So a person does not hit attack button before a player is pressed.
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            updateActionWindow();
            
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            }       
        }//End of middle hitter
    
        //2-Outside Hitter
        else if(e.getKeyCode() == KeyEvent.VK_W)
        {
            if(blockToggle)
            {
                if(OHBlockOn)
                {
                    blockerCount--;
                    OHBlockOn = false;
                    System.out.println("OHBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OHBlockOn = true;
                    System.out.println("OHBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }//iffirsttoggle
            
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? OH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter
        //3-Opposite Hitter
        else if(e.getKeyCode() == KeyEvent.VK_E)
        {
            if(blockToggle)
            {
                if(OPPBlockOn)
                {
                    blockerCount--;
                    OPPBlockOn = false;
                    System.out.println("OPPBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OPPBlockOn = true;
                    System.out.println("OPPBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("x");
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Opposite
        //4-Outside Hitter (Back Row)
        else if(e.getKeyCode() == KeyEvent.VK_R)
        {
            if(blockToggle)
            {
               if(OHBackBlockOn)
                {
                    blockerCount--;
                    OHBackBlockOn = false;
                    System.out.println("OHBackBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OHBackBlockOn = true;
                    System.out.println("OHBackBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                    }  
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter (Back Row)
        //5-Libero
        else if(e.getKeyCode() == KeyEvent.VK_T)
        {
            if(blockToggle)
            {
                if(LiberoBlockOn)
                {
                    blockerCount--;
                    LiberoBlockOn = false;
                    System.out.println("LiberoBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    LiberoBlockOn = true;
                    System.out.println("LiberoBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        if(team1LiberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(team2LiberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if(team1LiberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(team2LiberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }// End of Libero
        //6-Setter
        else if(e.getKeyCode() == KeyEvent.VK_Y)
        {
            if(blockToggle)
            {
                if(SetterBlockOn)
                {
                    blockerCount--;
                    SetterBlockOn = false;
                    System.out.println("SetterBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    SetterBlockOn = true;
                    System.out.println("SetterBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Setter
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
        
        //7-Attack
        else if(e.getKeyCode() == KeyEvent.VK_U)
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0) //When play is over turn it off
            {
                //firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "attack");
                updateActionWindow();
                contactCounter = 0;
                possession = !possession;
            }
        }
        //8-Over
        else if(e.getKeyCode() == KeyEvent.VK_I)
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                if(actionLog.get(actionLog.size()-1).equals("dig"))
                {
                    actionLog.set(actionLog.size()-1, ("dig&over"));
                }
                else
                {
                    
                    actionLog.set(actionLog.size()-1, "over");
                }
                updateActionWindow();
                overToggle = true;
                
                if(contactCounter != 0)
                {
                    contactCounter = 0;
                    possession = !possession;
                }
            }
        }
        //9-Continue
        else if(e.getKeyCode() == KeyEvent.VK_O)
        {
            if(firstButtonPressedToggle && !blockToggle)
            {
                playerLog.add(dummy);
                actionLog.add("continue");
                updateActionWindow();
                continueToggle = true;
                contactCounter = 0;
            }
        }
        //10-Kill
        else if(e.getKeyCode() == KeyEvent.VK_P)
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "kill");
                if(actionLog.get(actionLog.size()-2).contains("over"))
                {
                    
                }
                else if(actionLog.get(actionLog.size()-2).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-2, "receptionAttempt&assist");
                }
                else if(actionLog.get(actionLog.size()-2).equals("dig"))
                {
                    actionLog.set(actionLog.size()-2, "dig&assist");
                }
                else
                {
                    actionLog.set(actionLog.size()-2, "assist");
                }
                updateActionWindow();
                contactCounter = 0;
                possession=!possession;
                if(possession)
                {
                    team1Score++;
                }
                else
                {
                    team2Score++;
                }
                System.out.println("Score: " + team1Score + "-" + team2Score);
                rotate();
            }
        }
        //11-Block
        else if(e.getKeyCode() == KeyEvent.VK_A)
        {
            if(firstButtonPressedToggle)
            {
                blockToggle = true;
                System.out.println("SELECT BLOCKERS");
            }
        }
        //12-Error
        else if(e.getKeyCode() == KeyEvent.VK_S)
        {
            //Service Error
            if(!firstButtonPressedToggle && !blockToggle)
            {
                errorToggle = true;
                if(possession)
                {
                    for(int i=1; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                break;
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                break;
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                else
                {
                    for(int i=1; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                break;
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                break;
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                possession=!possession;
            }
            //Reception Error, Ball Handling Error, Attack Error, and blockError
            else //if(firstButtonPressedToggle && !blockToggle)
            {
                if(blockToggle)
                {
                    blockErrorToggle = true;
                    System.out.println("Select Blocker who errored");
                }
                else if(actionLog.get(actionLog.size()-1).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-1,"receptionError");
                    possession=!possession;
                    if(possession)
                    {
                        for(int i=0; i<7; i++)
                        {
                            if(team1Starters[i].getPlayerPosition()==1)
                            {
                                if(i==3 && team1LiberoInToggle)
                                {
                                    playerLog.add(team1Starters[0]);
                                    actionLog.add("serviceAce");

                                }
                                if(i==6 && team1LiberoInToggle)
                                {
                                    playerLog.add(team1Starters[0]);
                                    actionLog.add("serviceAce");
                                }
                                playerLog.add(team1Starters[i]);
                                actionLog.add("serviceAce");
                            }
                        }
                        serveTrack.insert(1);
                    }
                    else
                    {
                        for(int i=0; i<7; i++)
                        {
                            if(team2Starters[i].getPlayerPosition()==1)
                            {
                                if(i==3 && team2LiberoInToggle)
                                {
                                    playerLog.add(team2Starters[0]);
                                    actionLog.add("serviceAce");

                                }
                                if(i==6 && team2LiberoInToggle)
                                {
                                    playerLog.add(team2Starters[0]);
                                    actionLog.add("serviceAce");
                                }
                                playerLog.add(team2Starters[i]);
                                actionLog.add("serviceAce");
                            }
                        }
                        serveTrack.insert(0);
                    }
                }
                else if(actionLog.get(actionLog.size()-1).equals("zeroAssist") || actionLog.get(actionLog.size()-1).equals("over") || actionLog.get(actionLog.size()-1).equals("x"))
                {
                    actionLog.set(actionLog.size()-1,"Error");
                    possession=!possession;
                }
                else if(actionLog.get(actionLog.size()-1).equals("attack"))
                {
                    actionLog.set(actionLog.size()-1,"attackError");
                }
                else
                {
                    System.out.println("Wait... what the frickity? How'd we get here?");
                } 
            }//the quadrouple.
            firstButtonPressedToggle=false;
            updateActionWindow();
            contactCounter = 0;
            if(possession)
                {
                    team1Score++;
                }
                else
                {
                    team2Score++;
                }
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
        }//error
        
        //BallHandleError
        else if(e.getKeyCode() == KeyEvent.VK_N)
        {
            if(firstButtonPressedToggle && !blockToggle)
            {
                if(actionLog.get(actionLog.size()-1).equals("zeroAssist") || actionLog.get(actionLog.size()-1).equals("over") || actionLog.get(actionLog.size()-1).equals("x") || actionLog.get(actionLog.size()-1).equals("dig"))
                {
                    actionLog.set(actionLog.size()-1,"ballHandlingError");
                    possession=!possession;
                    firstButtonPressedToggle=false;
                    updateActionWindow();
                    contactCounter = 0;
                    if(possession)
                        {
                            team1Score++;
                        }
                        else
                        {
                            team2Score++;
                        }
                    System.out.println("Score: " + team1Score + "-" + team2Score);
                    rotate();
                }
            }
        }
        
        //13-Team Error
        else if(e.getKeyCode() == KeyEvent.VK_K)
        {
            System.out.println(actionLog.get(actionLog.size()-1));
            if((actionLog.get(actionLog.size()-1).equals("receptionAttempt")))
            {
                if(possession)
                {
                    actionLog.set(actionLog.size()-1, ("teamError"));
                    playerLog.set(playerLog.size()-1, (team1[30]));
                    team1Score++;
                }
                else
                {
                    actionLog.set(actionLog.size()-1, ("teamError"));
                    playerLog.set(playerLog.size()-1, (team1[30]));
                    team2Score++;
                }
                possession=!possession;
            }
            else if(chooseTeam()==1)
            {
                playerLog.add(team1[30]);
                actionLog.add("teamError");
                team2Score++;
                if(possession)
                {
                    possession=!possession;
                }
            }
            else
            {
                playerLog.add(team2[30]);
                actionLog.add("teamError");
                team1Score++;
                if(!possession)
                {
                    possession=!possession;
                }
            }
            firstButtonPressedToggle=false;
            updateActionWindow();
            contactCounter = 0;
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
        }
        
        //13-Substitution
        else if(e.getKeyCode() == KeyEvent.VK_M)
        {
            if(!blockToggle && contactCounter==0)
            {
                Player temp[] = new Player[1]; 
                boolean whichTeam=true;
                int playerComingInPosition=0;
                int in = 0;
                int out = 0;
                substitutionToggleOn = true;
                teamSubSelect = true;
                substitutionNumber = 0;
                System.out.println("Which Team?");
                while(teamSubSelect)
                {
                    if(homeTeamSubSelected)
                    {
                        whichTeam = true;
                        break;
                    }
                    else if(awayTeamSubSelected)
                    {
                        whichTeam = false;
                        break;
                    }
                }
                System.out.println("Player coming IN");
                while(!subEnterToggle)
                {
                    
                }
                in = substitutionNumber;
                subEnterToggle = false;
                substitutionNumber = 0;
                System.out.println("Player coming OUT");
                while(!subEnterToggle)
                {
                    
                }
                out = substitutionNumber;
                subEnterToggle = false;
                
                if(whichTeam)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == in)
                        {
                            temp[0]=team1[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerNumber() == out)
                        {
                            team1[playerComingInPosition]=team1Starters[i];
                            team1Starters[i]=temp[0];
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == in)
                        {
                            temp[0]=team2[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerNumber() == out)
                        {
                            team2[playerComingInPosition]=team2Starters[i];
                            team2Starters[i]=temp[0];
                        }
                    }
                }
            }
        }
        //14-Back
        else if(e.getKeyCode() == KeyEvent.VK_F)
        {
            
        }
        //15-Skip
        else if(e.getKeyCode() == KeyEvent.VK_G)
        {
            
        }
        //16-Enter
        else if(e.getKeyCode() == KeyEvent.VK_H)
        {
            
        }
        //16-Submit Block
        else if(e.getKeyCode() == KeyEvent.VK_J)
        {
            if(!blockErrorToggle && !blockToggle)
            {
                System.out.println("Is it possible to be here? What is life?");
                return;
            }
            firstButtonPressedToggle=false;
            
            
            
            if(blockToggle && !blockErrorToggle)
            {
                if(blockerCount == 1)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("soloBlock");
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("soloBlock");
                        }
                        SetterBlockOn = false;
                    }
                }
                else
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        MHBlockOn = false;
                    }
                    if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBlockOn = false;
                    }
                    if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockAssist");
                        }
                        OPPBlockOn = false;
                    }
                    if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockAssist");
                        }
                        SetterBlockOn = false;
                    }
                }
            }
            else if(blockToggle && blockErrorToggle)
            {            
                if(blockerCount == 1)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        SetterBlockOn = false;
                    }
                }
                else
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        MHBlockOn = false;
                    }
                    if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBlockOn = false;
                    }
                    if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockAssist");
                        }
                        OPPBlockOn = false;
                    }
                    if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockAssist");
                        }
                        SetterBlockOn = false;
                    }
                }
            }//block
            blockerCount = 0;
            updateActionWindow();
            if(possession)
            {
                team1Score++;
            }
            else
            {
                team2Score++;
            }
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
            blockToggle=false;
            blockErrorToggle=false;
        }
        
        //17-Team1LiberoInToggle
        else if(e.getKeyCode() == KeyEvent.VK_L)
        {
            team1LiberoInToggle=!team1LiberoInToggle;
        }
        //17-Team2LiberoInToggle
        else if(e.getKeyCode() == KeyEvent.VK_D)
        {
            team1LiberoInToggle=!team1LiberoInToggle;
        }
        //18-SubIncreaseNum+1
        else if(e.getKeyCode() == KeyEvent.VK_Z)
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    homeTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber++;
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-1
        else if(e.getKeyCode() == KeyEvent.VK_X)
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    awayTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber--;
                System.out.println("substitutionNumber");
            }
        }
        //18-SubIncreaseNum+10
        else if(e.getKeyCode() == KeyEvent.VK_C)
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-10
        else if(e.getKeyCode() == KeyEvent.VK_V)
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //EnterSub
        else if(e.getKeyCode() == KeyEvent.VK_B)
        {
            if(substitutionToggleOn)
            {
                subEnterToggle = true;
            }
        }
            
    }
        

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}   
*/


/*
package alu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.TextField;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;*/

//For other class: team recieve (falls between 2 players or out of rotation).
//Dig error: did he double it? Ball handling error then.

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */
/*
public class Player extends JFrame
{
    private Container container;
    private JPanel panel;
    private JTextArea actionWindow;
    private JTextArea promptWindow;
    
    
    public String name;
    public int number;
    public int position;
        
    private int receptionAttempts;
    private int receptionErrors;
    
    private int serviceAces;
    private int zeroServes;
    private int serviceErrors;
    
    private int digs;
    
    private int attacks;
    private int attackErrors;
    private int kills;
    
    private int assists;
    private int zeroAssists;
    private int ballHandlingErrors;
    
    private int soloBlocks;
    private int blockAssists;
    private int blockErrors;
    
  

    public Player()
    {
        super("ALUstats");
        
        
        
        name ="";
        number=0;
        position=0;
        
        receptionAttempts=0;
        receptionErrors=0;
        
        serviceAces=0;
        zeroServes=0;
        serviceErrors=0;
        
        digs=0;
        
        attacks=0;
        attackErrors=0;
        kills=0;
        
        assists=0;
        zeroAssists=0;
        ballHandlingErrors=0;
                
        soloBlocks=0;
        blockAssists=0;
        blockErrors=0;
    }
    
    
    
    
    
    
    
    //Enter name for player.
    public void setPlayerName()
    {
        System.out.println("Enter Player's Name");
        Scanner enter = new Scanner(System.in);
        name = enter.next();
    }//NamePlayer
    
    //Enter Player's number
    public void setPlayerNumber()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter Player's Number"); 
            try
            {
                num = enter.nextInt();
                number = num;
                pass = true;
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }   
    }//NumberPlayer
    
    //Enter Player's position
    public void setPlayerPosition()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter Player's Position"); 
            try
            {
                num = enter.nextInt();
                position = num;
                pass = true;
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }   
    }//PositionPlayer
    
    
    public void rotatePosition()
    {
        position--;
        if(position == 0)
        {
            position = 6;
        }
         
    }
    //+1 Reception Attempts
    public void addReceptionAttempts()
    {
        receptionAttempts++;
    }
    
    //+1 Reception Errors
    public void addReceptionErrors()
    {
        receptionErrors++;
    }
    
    //+1 Service Aces
    public void addServiceAces()
    {
        serviceAces++;
    }
    
    //+1 Zero Serves
    public void addZeroServes()
    {
        zeroServes++;
    }
    
    //+1 Service Errors
    public void addServiceErrors()
    {
        serviceErrors++;
    }
    
    //+1 Digs
    public void addDigs()
    {
        digs++;
    }
    
    //+1 Attacks
    public void addAttacks()
    {
        attacks++;
    }
    
    //+1 Attack Errors
    public void addAttackErrors()
    {
        attackErrors++;
    }
    
    //+1 Kills
    public void addKills()
    {
        kills++;
    }
    
    //+1 Assists
    public void addAssists()
    {
        assists++;
    }
    
    //+1 Zero Assists
    public void addZeroAssists()
    {
        zeroAssists++;
    }
    
    //+1 Ball Handeling Errors
    public void addBallHandlingErrors()
    {
        ballHandlingErrors++;
    }
    
    //+1 Solo Blocks
    public void addSoloBlocks()
    {
        soloBlocks++;
    }
    
    //+1 Block Assists
    public void addBlockAssists()
    {
        blockAssists++;
    }
    
    //+1 Block Errors
    public void addBlockErrors()
    {
        blockErrors++;
    }
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    //Return Player's name
    public String getPlayerName()
    {
        return name;
    }
    
    //Return Player's number
    public int getPlayerNumber()
    {
        return number;
    }
    
    //Return Player's position
    public int getPlayerPosition()
    {
        return position;
    }
    
    //+1 Reception Attempts
    public int getReceptionAttempts()
    {
        return receptionAttempts;
    }
    
    //+1 Reception Errors
    public int getReceptionErrors()
    {
        return receptionErrors;
    }
    
    //+1 Service Aces
    public int getServiceAces()
    {
        return serviceAces;
    }
    
    //+1 Zero Serves
    public int getZeroServes()
    {
        return zeroServes;
    }
    
    //+1 Service Errors
    public int getServiceErrors()
    {
        return serviceErrors;
    }
    
    //+1 Digs
    public int getDigs()
    {
        return digs;
    }
    
    //+1 Attacks
    public int getAttacks()
    {
        return attacks;
    }
    
    //+1 Attack Errors
    public int getAttackErrors()
    {
        return attackErrors;
    }
    
    //+1 Kills
    public int getKills()
    {
        return kills;
    }
    
    //+1 Assists
    public int getAssists()
    {
        return assists;
    }
    
    //+1 Zero Assists
    public int getZeroAssists()
    {
        return zeroAssists;
    }
    
    //+1 Ball Handeling Errors
    public int getBallHandlingErrors()
    {
        return ballHandlingErrors;
    }
    
    //+1 Solo Blocks
    public int getSoloBlocks()
    {
        return soloBlocks;
    }
    
    //+1 Block Assists
    public int getBlockAssists()
    {
        return blockAssists;
    }
    
    //+1 Block Errors
    public int getBlockErrors()
    {
        return blockErrors;
    }    
}   */

/*
public JTextArea getActionWindow()
    {
        return actionWindow;
    }
    
    
      
    
    
    
    
    
    
    
    
    public void initialize()
    {
        container = getContentPane();
        container.setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setVisible(true);
        setLayout(new GridBagLayout()); 
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        
        JButton b1 = new JButton("a");
        add(b1,c);
        
        c.gridy++;
        JButton b2 = new JButton("a");
        add(b2,c);
        
        c.gridy++;
        JButton b3 = new JButton("a");
        add(b3,c);
        
        c.gridy++;
        JButton b4 = new JButton("a");
        add(b4,c);
        
        c.gridy++;
        JButton b5 = new JButton("a");
        add(b5,c);
        
        c.gridy++;
        JButton b6 = new JButton("a");
        add(b6,c);
        
        c.gridy++;
        JButton b7 = new JButton("a");
        add(b7,c);
        
        c.gridy++;
        JButton b8 = new JButton("a");
        add(b8,c);
        
        c.gridy++;
        JButton b9 = new JButton("a");
        add(b9,c);
        
        c.gridy++;
        JButton b10 = new JButton("a");
        add(b10,c);
        
        c.gridy++;
        JButton b11 = new JButton("a");
        add(b11,c);
        
        c.gridy++;
        JButton b12 = new JButton("a");
        add(b12,c);
        
        c.gridy++;
        JButton b13 = new JButton("a");
        add(b13,c);
        
        c.gridy++;
        JButton b14 = new JButton("a");
        add(b14,c);
        
        c.gridy++;
        JButton b15 = new JButton("a");
        add(b15,c);
        
        c.gridy++;
        JButton b16 = new JButton("a");
        add(b16,c);
        
        c.gridy++;
        JButton b17 = new JButton("a");
        add(b17,c);
        
        c.gridy++;
        JButton b18 = new JButton("a");
        add(b18,c);
        
        c.gridy++;
        JButton b19 = new JButton("a");
        add(b19,c);
        
        c.gridy++;
        JButton b20 = new JButton("a");
        add(b20,c);
        
        c.gridy++;
        JButton b21 = new JButton("a");
        add(b21,c);
        
        c.gridy++;
        JButton b22 = new JButton("a");
        add(b22,c);
        
        c.gridy++;
        JButton b23 = new JButton("a");
        add(b23,c);
        
        c.gridy++;
        JButton b24 = new JButton("a");
        add(b24,c);
        
        c.gridy++;
        JButton b25 = new JButton("a");
        add(b25,c);
        
        c.gridy++;
        JButton b26 = new JButton("a");
        add(b26,c);
        
        c.gridy++;
        JButton b27 = new JButton("a");
        add(b27,c);
        
        c.gridy++;
        JButton b28 = new JButton("a");
        add(b28,c);
        
        c.gridy++;
        JButton b29 = new JButton("a");
        add(b29,c);
        
        c.gridy++;
        JButton b30 = new JButton("a");
        add(b30,c);
        
        
        c.gridx=1;
        c.gridy=2;
        JLabel l1 = new JLabel("S");
        add(l1,c);
        
        c.gridx=1;
        c.gridy=1;
        JLabel l2 = new JLabel("L");
        add(l2,c);
                
        c.gridx=1;
        c.gridy=0;
        JLabel l3 = new JLabel("OH1");
        add(l3,c);
        
        c.gridx=2;
        c.gridy=2;
        JLabel l4 = new JLabel("OH2");
        add(l4,c);
        
        c.gridx=2;
        c.gridy=1;
        JLabel l5 = new JLabel("MH2");
        add(l5,c);
                
        c.gridx=2;
        c.gridy=0;
        JLabel l6 = new JLabel("OP");
        add(l6,c);
        
        
        
        c.gridx=3;
        c.gridy=2;
        JLabel l7 = new JLabel("S");
        add(l7,c);
        
        c.gridx=3;
        c.gridy=1;
        JLabel l8 = new JLabel("L");
        add(l8,c);
                
        c.gridx=3;
        c.gridy=0;
        JLabel l9 = new JLabel("OH1");
        add(l9,c);
        
        c.gridx=4;
        c.gridy=2;
        JLabel l10 = new JLabel("OH2");
        add(l10,c);
        
        c.gridx=4;
        c.gridy=1;
        JLabel l11 = new JLabel("MH2");
        add(l11,c);
                
        c.gridx=4;
        c.gridy=0;
        JLabel l12 = new JLabel("OP");
        add(l12,c);
        
        
        
        
        c.gridx=1;
        c.gridy=3;
        c.gridheight=31;
        c.gridwidth=4;
        //c.gridwidth=29;
        
        actionWindow = new JTextArea(48, 48);
        actionWindow.setEditable(false);
        actionWindow.setFocusable(false);
        JScrollPane scrollPaneDAW = new JScrollPane(actionWindow);
        add(scrollPaneDAW,c);
        
        c.gridx=5;
        c.gridy=0;

        promptWindow = new JTextArea(49, 49);
        promptWindow.setEditable(false);
        promptWindow.setFocusable(false);
        JScrollPane scrollPanePW = new JScrollPane(promptWindow);
        add(scrollPanePW,c);
        
        
        
        
        //panel = getPanel();
        //panel.setFocusable(true);
        
         
        
    }*/