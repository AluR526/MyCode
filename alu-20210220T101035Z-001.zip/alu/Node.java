package alu;

/**
 * LinkedList
 * @author Ryan Alu, Saint Francis University
 * Jan 24, 2018
 */

//Creates a Node
public class Node
{
    public int data; //Value of node
    public Node prev; //Pointer
    public Node next; //Pointer
    
    //Create Node with initial value (null pointers)
    public Node(int n)
    {
        data = n;
        next = null;
        prev = null;
    }
    
    //Create Node with initial value and pointers
    public Node(int n, Node prev, Node next)
    {
        {
            data = n;
            this.prev = prev;
            this.next = next;
        }
    }
}   
