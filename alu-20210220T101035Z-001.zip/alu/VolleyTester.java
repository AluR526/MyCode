/*package alu;

import java.util.ArrayList;*/


/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Aug 2, 2018
 */

/*public class VolleyTester
{
    public static void main (String [] args)
    {
        Volley test = new Volley();
        test.init();
        //test.initialize();
        test.createRoster();
        
        test.createTeamsForTesting();
        
        /*test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        
        test.establishSetter();
        test.establishOH2();
        test.establishMH2();
        test.establishOP();
        test.establishOH1();
        test.establishMH1();
        test.establishLibero();
        test.establishLiberoR();
        
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        test.createPlayer();
        
        test.establishLibero();
        test.establishLiberoR();
        test.establishMH1();
        test.establishMH2();
        test.establishOH1();
        test.establishOH2();
        test.establishOP();
        test.establishSetter();*/
        
    /*}
    
}*/
