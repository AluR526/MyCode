package alu;

import java.awt.event.ActionEvent;
import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import java.awt.event.KeyAdapter;
import javax.swing.*;

import static java.awt.event.KeyEvent.*;

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Jun 1, 2018
 */

public class Volley extends Player implements KeyListener
{
    private DoubleLinkedListSideOutTracker serveTrack;
    private int contactCounter;
    private int team1Score;
    private int team2Score;
    
    private boolean firstButtonPressedToggle;
    private boolean continueToggle;
    private boolean overToggle;
    
    private boolean blockToggle;
    private boolean MHBlockOn;
    private boolean OHBlockOn;
    private boolean OPPBlockOn;
    private boolean OHBackBlockOn;
    private boolean LiberoBlockOn;
    private boolean SetterBlockOn;
    private int blockerCount;
    private boolean blockErrorToggle;
    
    private boolean substitutionToggleOn;
    private boolean subEnterToggle;
    private int substitutionNumber;
    private boolean teamSubSelect;
    private boolean homeTeamSubSelected;
    private boolean awayTeamSubSelected;
    
    private boolean team1LiberoInToggle;
    private boolean team2LiberoInToggle;
            
    private boolean possession; //Team 2- False. Team 1- True
    
    private ArrayList<Player> playerLog;
    private ArrayList<String> actionLog;
    
    
    private Player team1Starters[];
    private Player team2Starters[];
    private Player[] team1;
    private Player[] team2;
    private Player dummy;
    
    //MJK: Hashtable for number to player, and an enumeration for the positions
    //Protip:  use enums, soooo much easier to read.  Make them static if you want other
    //code to play with them
    private HashMap<Integer, Player> numberToPlayer;

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private enum Positions { 
    	SETTER(1), OH2(2), MH2(3), OP(4), OH1(5), MH1(6), LIBERO(0), LIBEROR(7);
    	private final int id;
        Positions(int id) { this.id = id; }
        public int getValue() { return id; }
        };
          
    
    public Volley()
    {   
        serveTrack = new DoubleLinkedListSideOutTracker();
        contactCounter = 0;
        team1Score = 0;
        team2Score = 0;
        
        firstButtonPressedToggle = false;
        continueToggle = false;
        overToggle = false;

        blockToggle = false;
        MHBlockOn = false;
        OHBlockOn = false;
        OPPBlockOn = false;
        OHBackBlockOn = false;
        LiberoBlockOn = false;
        SetterBlockOn = false;
        blockerCount = 0;
        blockErrorToggle = false;
        
        substitutionToggleOn = false;
        subEnterToggle = false;
        substitutionNumber = 0;
        teamSubSelect = false;
        homeTeamSubSelected = false;
        awayTeamSubSelected = false;
        
        team1LiberoInToggle = true;
        team2LiberoInToggle = true;
        
        possession = true;
        
        playerLog = new ArrayList(0);
        actionLog = new ArrayList(0);
        
        
        team1Starters = new Player[8];
        team2Starters = new Player[8];
        team1 = new Player[31];
        team2 = new Player[31];
        dummy = new Player();
        
    }
    
    public void handleKeyEvent(int event) {
    	switch(event) {
    	case VK_Q:
    		System.out.println("Ooooh Yeahhhhh hit Q");
                middleHitterQ();
    		break;
    	case VK_W:
    		System.out.println("Ooooh Yeahhhhh hit W");
                outsideHitterW();
    		break;
    	case VK_E:
    		System.out.println("Ooooh Yeahhhhh hit E");
                oppositeHitterE();
    		break;
        case VK_R:
    		System.out.println("Ooooh Yeahhhhh hit R");
                outsideHitterBackRowR();
    		break;
    	case VK_T:
    		System.out.println("Ooooh Yeahhhhh hit T");
                liberoT();
    		break;
    	case VK_Y:
    		System.out.println("Ooooh Yeahhhhh hit Y");
                setterY();
    		break;
        case VK_U:
    		System.out.println("Ooooh Yeahhhhh hit U");
                attackU();
    		break;
    	case VK_I:
    		System.out.println("Ooooh Yeahhhhh hit I");
                overI();
    		break;
    	case VK_O:
    		System.out.println("Ooooh Yeahhhhh hit O");
                continueO();
    		break;
        case VK_P:
    		System.out.println("Ooooh Yeahhhhh hit P");
                killP();
    		break;
    	case VK_A:
    		System.out.println("Ooooh Yeahhhhh hit A");
                blockA();
    		break;
    	case VK_S:
    		System.out.println("Ooooh Yeahhhhh hit S");
                errorS();
    		break;
        case VK_N:
    		System.out.println("Ooooh Yeahhhhh hit N");
                ballHandleErrorN();
    		break;
    	case VK_K:
    		System.out.println("Ooooh Yeahhhhh hit K");
                teamErrorK();
    		break;
    	case VK_M:
    		System.out.println("Ooooh Yeahhhhh hit M");
                substitutionM();
    		break;
        case VK_F:
    		System.out.println("Ooooh Yeahhhhh hit F");
                backF();
    		break;
    	case VK_G:
    		System.out.println("Ooooh Yeahhhhh hit G");
                skipG();
    		break;
    	case VK_H:
    		System.out.println("Ooooh Yeahhhhh hit H");
                enterH();
    		break;
        case VK_J:
    		System.out.println("Ooooh Yeahhhhh hit J");
                submitBlockJ();
    		break;
    	case VK_L:
    		System.out.println("Ooooh Yeahhhhh hit L");
                team1LiberoInToggleL();
    		break;
    	case VK_D:
    		System.out.println("Ooooh Yeahhhhh hit D");
                team2LiberoInToggleD();
    		break;
        case VK_Z:
    		System.out.println("Ooooh Yeahhhhh hit Z");
                subIncreaseNum1Z();
    		break;
    	case VK_X:
    		System.out.println("Ooooh Yeahhhhh hit X");
                subDecreaseNum1X();
    		break;
    	case VK_C:
    		System.out.println("Ooooh Yeahhhhh hit C");
                subIncreaseNum10C();
    		break;
        case VK_V:
    		System.out.println("Ooooh Yeahhhhh hit V");
                subDecreaseNum10V();
    		break;
    	case VK_B:
    		System.out.println("Ooooh Yeahhhhh hit B");
                enterSubB();
    		break;
    	default:
    		System.out.println("Not sure how you got here");
    		break;
    	}
    }
    
    public void init()
    {
        //this.addKeyListener(this);
    }
    
    public void createRoster()
    {
    	//MJK: So there's no reason to do individual player, that's the point of using an array anyways.
        for(int i = 0; i < 31; i++) {
        	//Notice combining both teams into the same loop to save cycles and easier to read code
        	team1[i] = new Player();
        	team2[i] = new Player();
        }
    }
    
    public int chooseTeam()
    {
        //Which Team
        Scanner enter = new Scanner(System.in);
        
        int num=0;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter which team (1 or 2)"); 
            try
            {
                num = enter.nextInt();
                pass = true;
                
                if(num<1 || num>2)
                {
                    pass = false;
                    System.out.println("Number is not 1 or 2. Reboot");
                }
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }//while
        return num;
    }
    
    public void createPlayer()
    {  
        if(chooseTeam()==1)
        {
            for(int i=0; i<30; i++)
            {
                if(team1[i].getPlayerName().equals(""))
                {
                    team1[i].setPlayerName();
                    team1[i].setPlayerNumber();
                    numberToPlayer.put(team1[i].getPlayerNumber(), team1[i]);
                    return;
                }
            }
        }
        else
        {
            for(int i=0; i<30; i++)
            {
                if(team2[i].getPlayerName().equals(""))
                {
                    team2[i].setPlayerName();
                    team2[i].setPlayerNumber();
                    numberToPlayer.put(team2[i].getPlayerNumber(), team2[i]);
                    return;
                }
            }
        }
    }//create Player
    
    
    //MJK: So I got rid of a few hundred lines of code with this.  Anytime you have that much code
    //that looks the same, there's almost always a better way.  This also leverages a hashtable that
    //maps player number to their Player object.  No more searching the arrays.
    //
    //To use:  establishPosition(SETTER)
    //You should make a Team object, and it should contain this
    public void establishPosition(Positions p) {
    	Scanner enter = new Scanner(System.in);
    	int num;
		boolean pass = false;
		
    	while(!pass)
    	{
    		switch(p) {
    		case SETTER:
    			System.out.println("Enter the number of the setter");
    			break;
    		case OH2:
    			System.out.println("Enter the number of the Outside Hitter 2 (Following Setter)");
    			break;
    		case MH2:
    			System.out.println("Enter the number of the Middle Hitter 2 (Follows OH2)");
    			break;
    		case OP:
    			System.out.println("Enter the number of the Opposite Hitter");
    			break;
    		case OH1:
    			System.out.println("Enter the number of the Outside Hitter 1(Follows Opposite)");
    			break;
    		case MH1:
    			System.out.println("Enter the number of the Middle Hitter 1");
    			break;
    		case LIBERO:
    			System.out.println("Enter the number of the Starting Libero");
    			break;
    		case LIBEROR:
    			System.out.println("Enter the number of the Reserved Libero");
    			break;
    		}

    		try
    		{
    			num = enter.nextInt();

    			if(numberToPlayer.containsKey(num)) {
    				team1Starters[p.getValue()] = numberToPlayer.get(num);
    				team1Starters[p.getValue()].setPlayerPosition();
    				return;
    			}
    			else {
    				System.out.println("A player with that number was never created. Reboot1");
    				pass = false;
    			}

    		}//try
    		catch(java.util.InputMismatchException ex)
    		{
    			System.out.println("Not a number. Reboot");
    			String garbage = enter.next();
    			pass = false;
    		}
    	}//While
    	
    	//MKJ: clean up yo shit with .close() :)
    	enter.close();
    }
    
    public void rotate()
    {
        if(serveTrack.last.prev.prev.data == serveTrack.last.prev.data)
        {
            return;
        }
        else if(possession)
        {
            team1Starters[0].rotatePosition();
            team1Starters[1].rotatePosition();
            team1Starters[2].rotatePosition();
            team1Starters[3].rotatePosition();
            team1Starters[4].rotatePosition();
            team1Starters[5].rotatePosition();
            team1Starters[6].rotatePosition();
            team1Starters[7].rotatePosition();
        }
        else
        {
            team2Starters[0].rotatePosition();
            team2Starters[1].rotatePosition();
            team2Starters[2].rotatePosition();
            team2Starters[3].rotatePosition();
            team2Starters[4].rotatePosition();
            team2Starters[5].rotatePosition();
            team2Starters[6].rotatePosition();
            team2Starters[7].rotatePosition();
        }
    }
    
    public int getContactCounter()
    {
        return contactCounter;
    }
    
    public void createTeamsForTesting()
    {
        serveTrack.insert(1);
        
        team1[0].name = "T1Setter";
        team1[0].number = 1;
        team1[1].name = "T1OH2";
        team1[1].number = 2;
        team1[2].name = "T1MH2";
        team1[2].number = 3;
        team1[3].name = "T1Oppo";
        team1[3].number = 4;
        team1[4].name = "T1OH1";
        team1[4].number = 5;
        team1[5].name = "T1MH1";
        team1[5].number = 6;
        team1[6].name = "T1Libero";
        team1[6].number = 7; 
        team1[7].name = "T1LiberoR";
        team1[7].number = 8;
        
        team1Starters[1] = team1[0];
        team1Starters[1].position = 1;
        team1Starters[2] = team1[1];
        team1Starters[2].position = 2;
        team1Starters[3] = team1[2];
        team1Starters[3].position = 3;
        team1Starters[4] = team1[3];
        team1Starters[4].position = 4;
        team1Starters[5] = team1[4];
        team1Starters[5].position = 5;
        team1Starters[6] = team1[5];
        team1Starters[6].position = 6;
        team1Starters[0] = team1[6];
        team1Starters[0].position = 6;
        team1Starters[7] = team1[7];
        team1Starters[7].position = 6;
        
        
        team2[0].name = "T2Setter";
        team2[0].number = 1;
        team2[1].name = "T2OH2";
        team2[1].number = 2;
        team2[2].name = "T2MH2";
        team2[2].number = 3;
        team2[3].name = "T2Oppo";
        team2[3].number = 4;
        team2[4].name = "T2OH1";
        team2[4].number = 5;
        team2[5].name = "T2MH1";
        team2[5].number = 6;
        team2[6].name = "T2Libero";
        team2[6].number = 7; 
        team2[7].name = "T2LiberoR";
        team2[7].number = 8;
        
        team2Starters[1] = team2[0];
        team2Starters[1].position = 1;
        team2Starters[2] = team2[1];
        team2Starters[2].position = 2;
        team2Starters[3] = team2[2];
        team2Starters[3].position = 3;
        team2Starters[4] = team2[3];
        team2Starters[4].position = 4;
        team2Starters[5] = team2[4];
        team2Starters[5].position = 5;
        team2Starters[6] = team2[5];
        team2Starters[6].position = 6;
        team2Starters[0] = team2[6];
        team2Starters[0].position = 6;
        team2Starters[7] = team2[7];
        team2Starters[7].position = 6;
        
    }
    
    public String updateActionWindow()
    { 
        String actionLine = "";
        for(int i=0; i<playerLog.size(); i++)
        {
            actionLine = actionLine + playerLog.get(i).getPlayerName() + " " + playerLog.get(i).getPlayerPosition() + " " + actionLog.get(i) + "\n";
        }
        return actionLine;
    }
    
    public void whoServesFirst()
    {
        if(chooseTeam()==1)
        {
            serveTrack.insert(1);
        }
        else
        {
            serveTrack.insert(0);
        }
    }
    
    
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`    

    
        //1-Middle Hitter
        public void middleHitterQ()
        {
            System.out.println("you typed a character and it was Q BIIIIITCH");
            if(blockToggle)
            {
                if(MHBlockOn)
                {
                    blockerCount--;
                    MHBlockOn = false;
                    System.out.println("MHBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    MHBlockOn = true;
                    System.out.println("MHBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }
            //So a person does not hit attack button before a player is pressed.
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[3]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[6]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[3]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[6]);
                        actionLog.add("attack");
                    }
                }
            }
            contactCounter++;
            updateActionWindow();
            
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            }       
        }//End of middle hitter
        //2-Outside Hitter
        public void outsideHitterW()
        {
            if(blockToggle)
            {
                if(OHBlockOn)
                {
                    blockerCount--;
                    OHBlockOn = false;
                    System.out.println("OHBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OHBlockOn = true;
                    System.out.println("OHBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("receptionAttempt");
                    }
                }
                firstButtonPressedToggle = true;
            }//iffirsttoggle
            
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? OH2
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter
        //3-Opposite Hitter
        public void oppositeHitterE()
        {
            if(blockToggle)
            {
                if(OPPBlockOn)
                {
                    blockerCount--;
                    OPPBlockOn = false;
                    System.out.println("OPPBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OPPBlockOn = true;
                    System.out.println("OPPBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("x");
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[4]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[4]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[4]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[4]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Opposite
        //4-Outside Hitter (Back Row)
        public void outsideHitterBackRowR()
        {
            if(blockToggle)
            {
               if(OHBackBlockOn)
                {
                    blockerCount--;
                    OHBackBlockOn = false;
                    System.out.println("OHBackBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    OHBackBlockOn = true;
                    System.out.println("OHBackBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("receptionAttempt");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        //Which Middle hitter is receiving credit? MH2
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("x");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("x");
                        }
                    }
                    //Team 2
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("x");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("x");
                        }
                    }  
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team1Starters[5]);
                            actionLog.add("dig");
                        }
                    }
                    else
                    {
                        if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[2]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            playerLog.add(team2Starters[5]);
                            actionLog.add("dig");
                        }
                    }  
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("zeroAssist");
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    //Which Middle hitter is receiving credit? MH2
                    if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team1Starters[2]);
                        actionLog.add("attack");
                    }
                    //MH1
                    else
                    {
                        playerLog.add(team1Starters[5]);
                        actionLog.add("attack");
                    }
                }
                //Team 2
                else
                {
                    if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                    {
                        playerLog.add(team2Starters[2]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        playerLog.add(team2Starters[5]);
                        actionLog.add("attack");
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Outside Hitter (Back Row)
        //5-Libero
        public void liberoT()
        {
            if(blockToggle)
            {
                if(LiberoBlockOn)
                {
                    blockerCount--;
                    LiberoBlockOn = false;
                    System.out.println("LiberoBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    LiberoBlockOn = true;
                    System.out.println("LiberoBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("receptionAttempt");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("receptionAttempt");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("receptionAttempt");
                        }
                    }
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        if(team1LiberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(team2LiberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("x");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("x");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("x");
                            }
                        }
                    }
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        if(team1LiberoInToggle)
                        {
                            playerLog.add(team1Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                    //Team 2
                    else
                    {
                        if(team2LiberoInToggle)
                        {
                            playerLog.add(team2Starters[0]);
                            actionLog.add("dig");
                        }
                        else
                        {
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("dig");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("dig");
                            }
                        }
                    }
                }//End of real dig.        
            }//End of first contact
            
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("zeroAssist");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("zeroAssist");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("zeroAssist");
                        }
                    }
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    if(team1LiberoInToggle)
                    {
                        playerLog.add(team1Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team1Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team1Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
                    //Team 2
                else
                {
                    if(team2LiberoInToggle)
                    {
                        playerLog.add(team2Starters[0]);
                        actionLog.add("attack");
                    }
                    else
                    {
                        if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                        {
                            playerLog.add(team2Starters[6]);
                            actionLog.add("attack");
                        }
                        //MH1
                        else
                        {
                            playerLog.add(team2Starters[3]);
                            actionLog.add("attack");
                        }
                    }
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }// End of Libero
        //6-Setter
        public void setterY()
        {
            if(blockToggle)
            {
                if(SetterBlockOn)
                {
                    blockerCount--;
                    SetterBlockOn = false;
                    System.out.println("SetterBlocker Off" + " " + blockerCount);
                }
                else
                {
                    blockerCount++;
                    SetterBlockOn = true;
                    System.out.println("SetterBlocker On" + " " + blockerCount);
                }
                return;
            }
            if(!firstButtonPressedToggle)
            {
                if(possession)
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(1);
                }
                else
                {
                    for(int i=0; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceAttempt");
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceAttempt");
                        }
                    }
                    serveTrack.insert(0);
                }
                
                possession = !possession;
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                    //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("receptionAttempt");
                }
                firstButtonPressedToggle = true;
            }
            //which contact? 0
            else if(contactCounter == 0)
            {
                //Will it be a real dig? No
                if(continueToggle || overToggle)
                {
                    //Which team has the ball? Team 1
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("x");                       
                    }
                    //Team 2
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("x");
                    } 
                    continueToggle = false;
                    overToggle = false;
                }//End of "Nonreal" dig.
                //Real Dig
                else
                {
                    if(possession)
                    {
                        playerLog.add(team1Starters[1]);
                        actionLog.add("dig");    
                    }
                    else
                    {
                        playerLog.add(team2Starters[1]);
                        actionLog.add("dig");
                    }  
                }//End of real dig.        
            }//End of first contact
            else if(contactCounter == 1)
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("zeroAssist");
                }                
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("zeroAssist");
                }
            }//end of second contact
            else
            {
                //Which team has the ball? Team 1
                if(possession)
                {
                    playerLog.add(team1Starters[1]);
                    actionLog.add("attack");
                }
                //Team 2
                else
                {
                    playerLog.add(team2Starters[1]);
                    actionLog.add("attack");
                }
            }
            updateActionWindow();
            contactCounter++;
            //Switch possession and reset contactCounter.
            if(contactCounter == 3)
            {
                possession = !possession;
                contactCounter = 0;
            } 
        }//End of Setter
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
        
        //7-Attack
        public void attackU()
        {
            if(firstButtonPressedToggle && !blockToggle && contactCounter>0) //When play is over turn it off
            {
                //firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "attack");
                updateActionWindow();
                contactCounter = 0;
                possession = !possession;
            }
        }
        //8-Over
        public void overI()
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                if(actionLog.get(actionLog.size()-1).equals("dig"))
                {
                    actionLog.set(actionLog.size()-1, ("dig&over"));
                }
                else
                {
                    
                    actionLog.set(actionLog.size()-1, "over");
                }
                updateActionWindow();
                overToggle = true;
                
                if(contactCounter != 0)
                {
                    contactCounter = 0;
                    possession = !possession;
                }
            }
        }
        //9-Continue
        public void continueO()
        {
            if(firstButtonPressedToggle && !blockToggle)
            {
                playerLog.add(dummy);
                actionLog.add("continue");
                updateActionWindow();
                continueToggle = true;
                contactCounter = 0;
            }
        }
        //10-Kill
        public void killP()
        {
            if(firstButtonPressedToggle && !blockToggle) //When play is over turn it off
            {
                firstButtonPressedToggle=false;
                actionLog.set(actionLog.size()-1, "kill");
                if(actionLog.get(actionLog.size()-2).contains("over"))
                {
                    
                }
                else if(actionLog.get(actionLog.size()-2).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-2, "receptionAttempt&assist");
                }
                else if(actionLog.get(actionLog.size()-2).equals("dig"))
                {
                    actionLog.set(actionLog.size()-2, "dig&assist");
                }
                else
                {
                    actionLog.set(actionLog.size()-2, "assist");
                }
                updateActionWindow();
                contactCounter = 0;
                possession=!possession;
                if(possession)
                {
                    team1Score++;
                }
                else
                {
                    team2Score++;
                }
                System.out.println("Score: " + team1Score + "-" + team2Score);
                rotate();
            }
        }
        //11-Block
        public void blockA()
        {
            if(firstButtonPressedToggle)
            {
                blockToggle = true;
                System.out.println("SELECT BLOCKERS");
            }
        }
        //12-Error
        public void errorS()
        {
            //Service Error
            if(!firstButtonPressedToggle && !blockToggle)
            {
                if(possession)
                {
                    for(int i=1; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                break;
                                
                            }
                            if(i==6 && team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("serviceError");
                                break;
                            }
                            playerLog.add(team1Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                else
                {
                    for(int i=1; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerPosition()==1)
                        {
                            if(i==3 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                break;
                                
                            }
                            if(i==6 && team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("serviceError");
                                break;
                            }
                            playerLog.add(team2Starters[i]);
                            actionLog.add("serviceError");
                        }
                    }
                }
                possession=!possession;
            }
            //Reception Error, Ball Handling Error, Attack Error, and blockError
            else //if(firstButtonPressedToggle && !blockToggle)
            {
                if(blockToggle)
                {
                    blockErrorToggle = true;
                    System.out.println("Select Blocker who errored");
                }
                else if(actionLog.get(actionLog.size()-1).equals("receptionAttempt"))
                {
                    actionLog.set(actionLog.size()-1,"receptionError");
                    possession=!possession;
                    if(possession)
                    {
                        for(int i=0; i<7; i++)
                        {
                            if(team1Starters[i].getPlayerPosition()==1)
                            {
                                if(i==3 && team1LiberoInToggle)
                                {
                                    playerLog.add(team1Starters[0]);
                                    actionLog.add("serviceAce");

                                }
                                if(i==6 && team1LiberoInToggle)
                                {
                                    playerLog.add(team1Starters[0]);
                                    actionLog.add("serviceAce");
                                }
                                playerLog.add(team1Starters[i]);
                                actionLog.add("serviceAce");
                            }
                        }
                        serveTrack.insert(1);
                    }
                    else
                    {
                        for(int i=0; i<7; i++)
                        {
                            if(team2Starters[i].getPlayerPosition()==1)
                            {
                                if(i==3 && team2LiberoInToggle)
                                {
                                    playerLog.add(team2Starters[0]);
                                    actionLog.add("serviceAce");

                                }
                                if(i==6 && team2LiberoInToggle)
                                {
                                    playerLog.add(team2Starters[0]);
                                    actionLog.add("serviceAce");
                                }
                                playerLog.add(team2Starters[i]);
                                actionLog.add("serviceAce");
                            }
                        }
                        serveTrack.insert(0);
                    }
                }
                else if(actionLog.get(actionLog.size()-1).equals("zeroAssist") || actionLog.get(actionLog.size()-1).equals("over") || actionLog.get(actionLog.size()-1).equals("x"))
                {
                    actionLog.set(actionLog.size()-1,"Error");
                    possession=!possession;
                }
                else if(actionLog.get(actionLog.size()-1).equals("attack"))
                {
                    actionLog.set(actionLog.size()-1,"attackError");
                }
                else
                {
                    System.out.println("Wait... what the frickity? How'd we get here?");
                } 
            }//the quadrouple.
            firstButtonPressedToggle=false;
            updateActionWindow();
            contactCounter = 0;
            if(possession)
                {
                    team1Score++;
                }
                else
                {
                    team2Score++;
                }
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
        }//error
        
        //BallHandleError
        public void ballHandleErrorN()
        {
            if(firstButtonPressedToggle && !blockToggle)
            {
                if(actionLog.get(actionLog.size()-1).equals("zeroAssist") || actionLog.get(actionLog.size()-1).equals("over") || actionLog.get(actionLog.size()-1).equals("x") || actionLog.get(actionLog.size()-1).equals("dig"))
                {
                    actionLog.set(actionLog.size()-1,"ballHandlingError");
                    possession=!possession;
                    firstButtonPressedToggle=false;
                    updateActionWindow();
                    contactCounter = 0;
                    if(possession)
                        {
                            team1Score++;
                        }
                        else
                        {
                            team2Score++;
                        }
                    System.out.println("Score: " + team1Score + "-" + team2Score);
                    rotate();
                }
            }
        }
        
        //13-Team Error
        public void teamErrorK()
        {
            System.out.println(actionLog.get(actionLog.size()-1));
            if((actionLog.get(actionLog.size()-1).equals("receptionAttempt")))
            {
                if(possession)
                {
                    actionLog.set(actionLog.size()-1, ("teamError"));
                    playerLog.set(playerLog.size()-1, (team1[30]));
                    team1Score++;
                }
                else
                {
                    actionLog.set(actionLog.size()-1, ("teamError"));
                    playerLog.set(playerLog.size()-1, (team1[30]));
                    team2Score++;
                }
                possession=!possession;
            }
            else if(chooseTeam()==1)
            {
                playerLog.add(team1[30]);
                actionLog.add("teamError");
                team2Score++;
                if(possession)
                {
                    possession=!possession;
                }
            }
            else
            {
                playerLog.add(team2[30]);
                actionLog.add("teamError");
                team1Score++;
                if(!possession)
                {
                    possession=!possession;
                }
            }
            firstButtonPressedToggle=false;
            updateActionWindow();
            contactCounter = 0;
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
        }
        
        //13-Substitution
        public void substitutionM()
        {
            if(!blockToggle && contactCounter==0)
            {
                Player temp[] = new Player[1]; 
                boolean whichTeam=true;
                int playerComingInPosition=0;
                int in = 0;
                int out = 0;
                substitutionToggleOn = true;
                teamSubSelect = true;
                substitutionNumber = 0;
                System.out.println("Which Team?");
                while(teamSubSelect)
                {
                    if(homeTeamSubSelected)
                    {
                        whichTeam = true;
                        break;
                    }
                    else if(awayTeamSubSelected)
                    {
                        whichTeam = false;
                        break;
                    }
                }
                System.out.println("Player coming IN");
                while(!subEnterToggle)
                {
                    
                }
                in = substitutionNumber;
                subEnterToggle = false;
                substitutionNumber = 0;
                System.out.println("Player coming OUT");
                while(!subEnterToggle)
                {
                    
                }
                out = substitutionNumber;
                subEnterToggle = false;
                
                if(whichTeam)
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team1[i].getPlayerNumber() == in)
                        {
                            temp[0]=team1[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team1Starters[i].getPlayerNumber() == out)
                        {
                            team1[playerComingInPosition]=team1Starters[i];
                            team1Starters[i]=temp[0];
                        }
                    }
                }
                else
                {
                    for(int i=0; i<30; i++)
                    {
                        if(team2[i].getPlayerNumber() == in)
                        {
                            temp[0]=team2[i];
                            playerComingInPosition=i;
                        }
                    }
                    for(int i=1; i<7; i++)
                    {
                        if(team2Starters[i].getPlayerNumber() == out)
                        {
                            team2[playerComingInPosition]=team2Starters[i];
                            team2Starters[i]=temp[0];
                        }
                    }
                }
            }
        }
        //14-Back
        public void backF()
        {
            
        }
        //15-Skip
        public void skipG()
        {
            
        }
        //16-Enter
        public void enterH()
        {
            
        }
        //16-Submit Block
        public void submitBlockJ()
        {
            if(!blockErrorToggle && !blockToggle)
            {
                System.out.println("Is it possible to be here? What is life?");
                return;
            }
            firstButtonPressedToggle=false;
            
            
            
            if(blockToggle && !blockErrorToggle)
            {
                if(blockerCount == 1)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("soloBlock");
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("soloBlock");
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("soloBlock");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("soloBlock");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("soloBlock");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("soloBlock");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("soloBlock");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("soloBlock");
                        }
                        SetterBlockOn = false;
                    }
                }
                else
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        MHBlockOn = false;
                    }
                    if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBlockOn = false;
                    }
                    if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockAssist");
                        }
                        OPPBlockOn = false;
                    }
                    if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockAssist");
                        }
                        SetterBlockOn = false;
                    }
                }
            }
            else if(blockToggle && blockErrorToggle)
            {            
                if(blockerCount == 1)
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        MHBlockOn = false;
                    }
                    else if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        OHBlockOn = false;
                    }
                    else if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        OPPBlockOn = false;
                    }
                    else if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    else if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockError");
                                actionLog.set(actionLog.size()-2, ("kill"));
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockError");
                                    actionLog.set(actionLog.size()-2, ("kill"));
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    else if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockError");
                            actionLog.set(actionLog.size()-2, ("kill"));
                        }
                        SetterBlockOn = false;
                    }
                }
                else
                {
                    if(MHBlockOn)
                    {
                        if(possession)
                        {
                        //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[3].getPlayerPosition()%6)==4 || (team2Starters[3].getPlayerPosition()%6)==3 || (team2Starters[3].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[3]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[6]);
                                actionLog.add("blockAssist");
                            }
                        }
                        MHBlockOn = false;
                    }
                    if(OHBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? OH2
                            if((team1Starters[2].getPlayerPosition()%6)==4 || (team1Starters[2].getPlayerPosition()%6)==3 || (team1Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[2].getPlayerPosition()%6)==4 || (team2Starters[2].getPlayerPosition()%6)==3 || (team2Starters[2].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBlockOn = false;
                    }
                    if(OPPBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[4]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[4]);
                            actionLog.add("blockAssist");
                        }
                        OPPBlockOn = false;
                    }
                    if(OHBackBlockOn)
                    {
                        if(possession)
                        {
                            //Which Middle hitter is receiving credit? MH2
                            if((team1Starters[5].getPlayerPosition()%6)==4 || (team1Starters[5].getPlayerPosition()%6)==3 || (team1Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team1Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            //MH1
                            else
                            {
                                playerLog.add(team1Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        //Team 2
                        else
                        {
                            if((team2Starters[5].getPlayerPosition()%6)==4 || (team2Starters[5].getPlayerPosition()%6)==3 || (team2Starters[5].getPlayerPosition()%6)==2)
                            {
                                playerLog.add(team2Starters[5]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                playerLog.add(team2Starters[2]);
                                actionLog.add("blockAssist");
                            }
                        }
                        OHBackBlockOn = false;
                    }
                    if(LiberoBlockOn)
                    {
                        if(possession)
                        {
                            if(team1LiberoInToggle)
                            {
                                playerLog.add(team1Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team1Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team1Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        //Team 2
                        else
                        {
                            if(team2LiberoInToggle)
                            {
                                playerLog.add(team2Starters[0]);
                                actionLog.add("blockAssist");
                            }
                            else
                            {
                                if((team1Starters[3].getPlayerPosition()%6)==4 || (team1Starters[3].getPlayerPosition()%6)==3 || (team1Starters[3].getPlayerPosition()%6)==2)
                                {
                                    playerLog.add(team2Starters[3]);
                                    actionLog.add("blockAssist");
                                }
                                //MH1
                                else
                                {
                                    playerLog.add(team2Starters[6]);
                                    actionLog.add("blockAssist");
                                }
                            }
                        }
                        LiberoBlockOn = false;
                    }
                    if(SetterBlockOn)
                    {
                        if(possession)
                        {
                            playerLog.add(team1Starters[1]);
                            actionLog.add("blockAssist");                       
                        }
                        //Team 2
                        else
                        {
                            playerLog.add(team2Starters[1]);
                            actionLog.add("blockAssist");
                        }
                        SetterBlockOn = false;
                    }
                }
            }//block
            blockerCount = 0;
            updateActionWindow();
            if(possession)
            {
                team1Score++;
            }
            else
            {
                team2Score++;
            }
            System.out.println("Score: " + team1Score + "-" + team2Score);
            rotate();
            blockToggle=false;
            blockErrorToggle=false;
        }
        
        //17-Team1LiberoInToggle
        public void team1LiberoInToggleL()
        {
            team1LiberoInToggle=!team1LiberoInToggle;
        }
        //17-Team2LiberoInToggle
        public void team2LiberoInToggleD()
        {
            team1LiberoInToggle=!team1LiberoInToggle;
        }
        //18-SubIncreaseNum+1
        public void subIncreaseNum1Z()
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    homeTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber++;
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-1
        public void subDecreaseNum1X()
        {
            if(substitutionToggleOn)
            {
                if(teamSubSelect)
                {
                    awayTeamSubSelected = true;
                    teamSubSelect = false;
                    return;
                }
                substitutionNumber--;
                System.out.println("substitutionNumber");
            }
        }
        //18-SubIncreaseNum+10
        public void subIncreaseNum10C()
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //19-SubDecreaseNum-10
        public void subDecreaseNum10V()
        {
            if(substitutionToggleOn)
            {
                substitutionNumber = (substitutionNumber + 10);
                System.out.println("substitutionNumber");
            }
        }
        //EnterSub
        public void enterSubB()
        {
            if(substitutionToggleOn)
            {
                subEnterToggle = true;
            }
        }
            
    }  