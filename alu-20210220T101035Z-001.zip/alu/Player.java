package alu;

import java.util.Scanner;

public class Player {
	public String name;
    public int number;
    public int position;
        
    private int receptionAttempts;
    private int receptionErrors;
    
    private int serviceAces;
    private int zeroServes;
    private int serviceErrors;
    
    private int digs;
    
    private int attacks;
    private int attackErrors;
    private int kills;
    
    private int assists;
    private int zeroAssists;
    private int ballHandlingErrors;
    
    private int soloBlocks;
    private int blockAssists;
    private int blockErrors;
    
    public Player()
    {
        name ="";
        number=0;
        position=0;
        
        receptionAttempts=0;
        receptionErrors=0;
        
        serviceAces=0;
        zeroServes=0;
        serviceErrors=0;
        
        digs=0;
        
        attacks=0;
        attackErrors=0;
        kills=0;
        
        assists=0;
        zeroAssists=0;
        ballHandlingErrors=0;
                
        soloBlocks=0;
        blockAssists=0;
        blockErrors=0;
    }
    public void setPlayerName()
    {
        System.out.println("Enter Player's Name");
        Scanner enter = new Scanner(System.in);
        name = enter.next();
    }//NamePlayer
    
    //Enter PlayerOG's number
    public void setPlayerNumber()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter Player's Number"); 
            try
            {
                num = enter.nextInt();
                number = num;
                pass = true;
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }   
    }//NumberPlayer
    
    //Enter PlayerOG's position
    public void setPlayerPosition()
    {
        Scanner enter = new Scanner(System.in);
        
        int num;
        boolean pass = false;
        
        //Make sure user input is a number.
        while(!pass)
        {
            System.out.println("Enter Player's Position"); 
            try
            {
                num = enter.nextInt();
                position = num;
                pass = true;
            }
            catch(java.util.InputMismatchException ex)
            {
                System.out.println("Not a number. Reboot");
                String garbage = enter.next();
                pass = false;
            }
        }   
    }//PositionPlayer
    
    
    public void rotatePosition()
    {
        position--;
        if(position == 0)
        {
            position = 6;
        }
         
    }
    //+1 Reception Attempts
    public void addReceptionAttempts()
    {
        receptionAttempts++;
    }
    
    //+1 Reception Errors
    public void addReceptionErrors()
    {
        receptionErrors++;
    }
    
    //+1 Service Aces
    public void addServiceAces()
    {
        serviceAces++;
    }
    
    //+1 Zero Serves
    public void addZeroServes()
    {
        zeroServes++;
    }
    
    //+1 Service Errors
    public void addServiceErrors()
    {
        serviceErrors++;
    }
    
    //+1 Digs
    public void addDigs()
    {
        digs++;
    }
    
    //+1 Attacks
    public void addAttacks()
    {
        attacks++;
    }
    
    //+1 Attack Errors
    public void addAttackErrors()
    {
        attackErrors++;
    }
    
    //+1 Kills
    public void addKills()
    {
        kills++;
    }
    
    //+1 Assists
    public void addAssists()
    {
        assists++;
    }
    
    //+1 Zero Assists
    public void addZeroAssists()
    {
        zeroAssists++;
    }
    
    //+1 Ball Handeling Errors
    public void addBallHandlingErrors()
    {
        ballHandlingErrors++;
    }
    
    //+1 Solo Blocks
    public void addSoloBlocks()
    {
        soloBlocks++;
    }
    
    //+1 Block Assists
    public void addBlockAssists()
    {
        blockAssists++;
    }
    
    //+1 Block Errors
    public void addBlockErrors()
    {
        blockErrors++;
    }
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    //Return PlayerOG's name
    public String getPlayerName()
    {
        return name;
    }
    
    //Return PlayerOG's number
    public int getPlayerNumber()
    {
        return number;
    }
    
    //Return PlayerOG's position
    public int getPlayerPosition()
    {
        return position;
    }
    
    //+1 Reception Attempts
    public int getReceptionAttempts()
    {
        return receptionAttempts;
    }
    
    //+1 Reception Errors
    public int getReceptionErrors()
    {
        return receptionErrors;
    }
    
    //+1 Service Aces
    public int getServiceAces()
    {
        return serviceAces;
    }
    
    //+1 Zero Serves
    public int getZeroServes()
    {
        return zeroServes;
    }
    
    //+1 Service Errors
    public int getServiceErrors()
    {
        return serviceErrors;
    }
    
    //+1 Digs
    public int getDigs()
    {
        return digs;
    }
    
    //+1 Attacks
    public int getAttacks()
    {
        return attacks;
    }
    
    //+1 Attack Errors
    public int getAttackErrors()
    {
        return attackErrors;
    }
    
    //+1 Kills
    public int getKills()
    {
        return kills;
    }
    
    //+1 Assists
    public int getAssists()
    {
        return assists;
    }
    
    //+1 Zero Assists
    public int getZeroAssists()
    {
        return zeroAssists;
    }
    
    //+1 Ball Handeling Errors
    public int getBallHandlingErrors()
    {
        return ballHandlingErrors;
    }
    
    //+1 Solo Blocks
    public int getSoloBlocks()
    {
        return soloBlocks;
    }
    
    //+1 Block Assists
    public int getBlockAssists()
    {
        return blockAssists;
    }
    
    //+1 Block Errors
    public int getBlockErrors()
    {
        return blockErrors;
    }
}
