package alu;

/**
 * VolleyballStat
 * @author Ryan Alu, Saint Francis University
 * Aug 9, 2018
 */

public class DoubleLinkedListSideOutTracker
{
    public Node first;
    public Node last;
    public DoubleLinkedListSideOutTracker()
    {
        //Dummy Node creation
        first = new Node(0);
        last = new Node(0);
        first.next = last;
        last.prev = first;
    }
    
    //Inserts a node anywhere in the doubly linked list
    public void insert(int j)
    {
        Node curr;
        Node temp = new Node(j);
        
        curr = first.next;
        while(curr.next != null) //While curr is not at end (on the "last" dummy node)
        {
            if(temp.data <= curr.data)
            {
                curr.prev.next = temp;
                temp.next = curr;
                temp.prev = curr.prev;
                curr.prev = temp;
                //System.out.println("INSERTED"); //Inform user is item was inserted
                break;
            }
            curr = curr.next;
        }
        if(curr.next == null)
        {
            curr.prev.next = temp;
            temp.next = curr;
            temp.prev = curr.prev;
            curr.prev = temp;
            //System.out.println("INSERTED"); //Inform user is item was inserted
        }
    }//insert
    
    //deletes a node in the list if it is in the list
    public void delete(int j)
    {
        Node curr;
        curr = first.next;
        
        while(curr.next != null)
        {
            if(curr.data == j)
            {
                curr.prev.next = curr.next;
                curr.next.prev = curr.prev;
                //System.out.println("DELETED");
                break;
            }
            if(curr.data > j)
            {
                //System.out.println("It's not in there -- nothing DELETED"); //Informs user if the item they wanted to delete was not in the list
                return;
            }
            curr = curr.next;
        }
        if(curr.next == null)
        {
            //System.out.println("It's not in there -- nothing DELETED"); //Informs user if the item they wanted to delete was not in the list
        }
    }//delete
    
    //True if the node is in the list. False otherwise.
    public boolean member(int j)
    {
        Node curr;
        curr = first.next;
        
        while(curr.next != null)
        {
            if(curr.data == j)
            {
                return true;
            }
            if(curr.data > j)
            {
                return false;
            }
            curr = curr.next;
        }
        return false; 
    }//member
    
    //Prints every node data in the list
    public void print()
    {
        Node curr;
        curr = first.next;
        
        if(curr.next == null)
        {
            //System.out.println("List is EMPTY!");
        }
        
        while(curr.next != null)
        {
            //System.out.println(curr.data);
            curr = curr.next;
        }
    }//print
    
    //Quits application
    public void quit()
    {
        System.exit(0);
    }
}   
